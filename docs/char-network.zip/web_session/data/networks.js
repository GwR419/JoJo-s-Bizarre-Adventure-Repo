var networks = {"char-network.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "char-network.tsv",
    "name" : "char-network.tsv",
    "SUID" : 155,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "608",
        "shared_name" : "01",
        "name" : "01",
        "Column_2" : "epTitle",
        "SUID" : 608,
        "selected" : false
      },
      "position" : {
        "x" : -3452.985121921666,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "606",
        "shared_name" : "Guy",
        "name" : "Guy",
        "Column_2" : "",
        "SUID" : 606,
        "selected" : false
      },
      "position" : {
        "x" : 2293.3562183561125,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "604",
        "shared_name" : "Girl",
        "name" : "Girl",
        "Column_2" : "",
        "SUID" : 604,
        "selected" : false
      },
      "position" : {
        "x" : 968.3312183561111,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "shared_name" : "Cop",
        "name" : "Cop",
        "Column_2" : "",
        "SUID" : 602,
        "selected" : false
      },
      "position" : {
        "x" : -4151.735121921666,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "600",
        "shared_name" : "Kid",
        "name" : "Kid",
        "Column_2" : "",
        "SUID" : 600,
        "selected" : false
      },
      "position" : {
        "x" : 1765.8812183561104,
        "y" : 398.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "598",
        "shared_name" : "Girls",
        "name" : "Girls",
        "Column_2" : "",
        "SUID" : 598,
        "selected" : false
      },
      "position" : {
        "x" : -3500.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "shared_name" : "Creep",
        "name" : "Creep",
        "Column_2" : "",
        "SUID" : 596,
        "selected" : false
      },
      "position" : {
        "x" : 1575.8812183561104,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "594",
        "shared_name" : "Driver",
        "name" : "Driver",
        "Column_2" : "",
        "SUID" : 594,
        "selected" : false
      },
      "position" : {
        "x" : -3690.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "592",
        "shared_name" : "Luca",
        "name" : "Luca",
        "Column_2" : "",
        "SUID" : 592,
        "selected" : false
      },
      "position" : {
        "x" : -3405.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "shared_name" : "Giorno",
        "name" : "Giorno",
        "Column_2" : "",
        "SUID" : 590,
        "selected" : false
      },
      "position" : {
        "x" : -3880.485121921666,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "shared_name" : "Koichi",
        "name" : "Koichi",
        "Column_2" : "",
        "SUID" : 588,
        "selected" : false
      },
      "position" : {
        "x" : 1074.59371835611,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "shared_name" : "Whack,Sfx",
        "name" : "Whack,Sfx",
        "Column_2" : "",
        "SUID" : 586,
        "selected" : false
      },
      "position" : {
        "x" : -3310.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "shared_name" : "Jotaro",
        "name" : "Jotaro",
        "Column_2" : "",
        "SUID" : 584,
        "selected" : false
      },
      "position" : {
        "x" : 979.5937183561109,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "582",
        "shared_name" : "Act",
        "name" : "Act",
        "Column_2" : "",
        "SUID" : 582,
        "selected" : false
      },
      "position" : {
        "x" : -3215.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "580",
        "shared_name" : "Sign",
        "name" : "Sign",
        "Column_2" : "",
        "SUID" : 580,
        "selected" : false
      },
      "position" : {
        "x" : -1661.6684552549991,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "shared_name" : "Glob",
        "name" : "Glob",
        "Column_2" : "",
        "SUID" : 578,
        "selected" : false
      },
      "position" : {
        "x" : -3595.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "576",
        "shared_name" : "Bruno",
        "name" : "Bruno",
        "Column_2" : "",
        "SUID" : 576,
        "selected" : false
      },
      "position" : {
        "x" : 1860.8812183561104,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "574",
        "shared_name" : "02",
        "name" : "02",
        "Column_2" : "epTitle",
        "SUID" : 574,
        "selected" : false
      },
      "position" : {
        "x" : -4307.985121921666,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "shared_name" : "Mom",
        "name" : "Mom",
        "Column_2" : "",
        "SUID" : 572,
        "selected" : false
      },
      "position" : {
        "x" : -4545.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "570",
        "shared_name" : "Shiobana,Sign",
        "name" : "Shiobana,Sign",
        "Column_2" : "",
        "SUID" : 570,
        "selected" : false
      },
      "position" : {
        "x" : -4165.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "568",
        "shared_name" : "Dad",
        "name" : "Dad",
        "Column_2" : "",
        "SUID" : 568,
        "selected" : false
      },
      "position" : {
        "x" : -4735.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "shared_name" : "Popo",
        "name" : "Popo",
        "Column_2" : "",
        "SUID" : 566,
        "selected" : false
      },
      "position" : {
        "x" : -4070.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "564",
        "shared_name" : "Kids",
        "name" : "Kids",
        "Column_2" : "",
        "SUID" : 564,
        "selected" : false
      },
      "position" : {
        "x" : -4260.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "562",
        "shared_name" : "X",
        "name" : "X",
        "Column_2" : "",
        "SUID" : 562,
        "selected" : false
      },
      "position" : {
        "x" : -3975.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "shared_name" : "Lady",
        "name" : "Lady",
        "Column_2" : "",
        "SUID" : 560,
        "selected" : false
      },
      "position" : {
        "x" : -1980.4851219216666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "558",
        "shared_name" : "Gold",
        "name" : "Gold",
        "Column_2" : "",
        "SUID" : 558,
        "selected" : false
      },
      "position" : {
        "x" : 1169.59371835611,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "556",
        "shared_name" : "Bagyah,Sfx",
        "name" : "Bagyah,Sfx",
        "Column_2" : "",
        "SUID" : 556,
        "selected" : false
      },
      "position" : {
        "x" : 1454.59371835611,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "shared_name" : "Rumble,Sfx",
        "name" : "Rumble,Sfx",
        "Column_2" : "",
        "SUID" : 554,
        "selected" : false
      },
      "position" : {
        "x" : -4450.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "552",
        "shared_name" : "Whoosh,Sfx",
        "name" : "Whoosh,Sfx",
        "Column_2" : "",
        "SUID" : 552,
        "selected" : false
      },
      "position" : {
        "x" : 1860.8812183561104,
        "y" : 398.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "550",
        "shared_name" : "Boom,Sfx",
        "name" : "Boom,Sfx",
        "Column_2" : "",
        "SUID" : 550,
        "selected" : false
      },
      "position" : {
        "x" : -3880.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "shared_name" : "Kabaam,Sfx",
        "name" : "Kabaam,Sfx",
        "Column_2" : "",
        "SUID" : 548,
        "selected" : false
      },
      "position" : {
        "x" : -4640.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "546",
        "shared_name" : "Guy C",
        "name" : "Guy C",
        "Column_2" : "",
        "SUID" : 546,
        "selected" : false
      },
      "position" : {
        "x" : -3785.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "544",
        "shared_name" : "Jump,Sfx",
        "name" : "Jump,Sfx",
        "Column_2" : "",
        "SUID" : 544,
        "selected" : false
      },
      "position" : {
        "x" : -4830.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "shared_name" : "Thud,Sfx",
        "name" : "Thud,Sfx",
        "Column_2" : "",
        "SUID" : 542,
        "selected" : false
      },
      "position" : {
        "x" : -4355.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "540",
        "shared_name" : "03",
        "name" : "03",
        "Column_2" : "epTitle",
        "SUID" : 540,
        "selected" : false
      },
      "position" : {
        "x" : 1860.8812183561104,
        "y" : 323.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "shared_name" : "Loom,Sfx",
        "name" : "Loom,Sfx",
        "Column_2" : "",
        "SUID" : 538,
        "selected" : false
      },
      "position" : {
        "x" : 1955.8812183561104,
        "y" : 398.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "shared_name" : "Polpo",
        "name" : "Polpo",
        "Column_2" : "",
        "SUID" : 536,
        "selected" : false
      },
      "position" : {
        "x" : 1359.59371835611,
        "y" : -201.82329059106593
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "534",
        "shared_name" : "Old",
        "name" : "Old",
        "Column_2" : "",
        "SUID" : 534,
        "selected" : false
      },
      "position" : {
        "x" : -2075.4851219216666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "532",
        "shared_name" : "Black",
        "name" : "Black",
        "Column_2" : "",
        "SUID" : 532,
        "selected" : false
      },
      "position" : {
        "x" : 884.5937183561109,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "shared_name" : "04",
        "name" : "04",
        "Column_2" : "epTitle",
        "SUID" : 530,
        "selected" : false
      },
      "position" : {
        "x" : 1074.593718356111,
        "y" : -126.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "528",
        "shared_name" : "Girono",
        "name" : "Girono",
        "Column_2" : "",
        "SUID" : 528,
        "selected" : false
      },
      "position" : {
        "x" : 1169.59371835611,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "526",
        "shared_name" : "Reverb",
        "name" : "Reverb",
        "Column_2" : "",
        "SUID" : 526,
        "selected" : false
      },
      "position" : {
        "x" : 1264.59371835611,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "shared_name" : "Bam,Sfx",
        "name" : "Bam,Sfx",
        "Column_2" : "",
        "SUID" : 524,
        "selected" : false
      },
      "position" : {
        "x" : -37.564614977222845,
        "y" : 98.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "522",
        "shared_name" : "The_Next_Day,Sign",
        "name" : "The_Next_Day,Sign",
        "Column_2" : "",
        "SUID" : 522,
        "selected" : false
      },
      "position" : {
        "x" : 1074.593718356111,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "520",
        "shared_name" : "05",
        "name" : "05",
        "Column_2" : "epTitle",
        "SUID" : 520,
        "selected" : false
      },
      "position" : {
        "x" : 409.5937183561118,
        "y" : -126.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "shared_name" : "Sale",
        "name" : "Sale",
        "Column_2" : "",
        "SUID" : 518,
        "selected" : false
      },
      "position" : {
        "x" : 314.5937183561118,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "516",
        "shared_name" : "Mario",
        "name" : "Mario",
        "Column_2" : "",
        "SUID" : 516,
        "selected" : false
      },
      "position" : {
        "x" : 219.59371835611182,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "514",
        "shared_name" : "Rome___a_m_,Sign",
        "name" : "Rome___a_m_,Sign",
        "Column_2" : "",
        "SUID" : 514,
        "selected" : false
      },
      "position" : {
        "x" : 29.593718356111822,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "shared_name" : "Nara",
        "name" : "Nara",
        "Column_2" : "",
        "SUID" : 512,
        "selected" : false
      },
      "position" : {
        "x" : 504.5937183561109,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "510",
        "shared_name" : "Waiter",
        "name" : "Waiter",
        "Column_2" : "",
        "SUID" : 510,
        "selected" : false
      },
      "position" : {
        "x" : 409.5937183561118,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "508",
        "shared_name" : "Fugo",
        "name" : "Fugo",
        "Column_2" : "",
        "SUID" : 508,
        "selected" : false
      },
      "position" : {
        "x" : 409.5937183561109,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "shared_name" : "Mista",
        "name" : "Mista",
        "Column_2" : "",
        "SUID" : 506,
        "selected" : false
      },
      "position" : {
        "x" : -441.31461497722285,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "504",
        "shared_name" : "Crunch,Sfx",
        "name" : "Crunch,Sfx",
        "Column_2" : "",
        "SUID" : 504,
        "selected" : false
      },
      "position" : {
        "x" : 1728.331218356111,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "502",
        "shared_name" : "Bg fugo",
        "name" : "Bg fugo",
        "Column_2" : "",
        "SUID" : 502,
        "selected" : false
      },
      "position" : {
        "x" : 504.5937183561118,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "shared_name" : "Abba",
        "name" : "Abba",
        "Column_2" : "",
        "SUID" : 500,
        "selected" : false
      },
      "position" : {
        "x" : 645.0640308561115,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "498",
        "shared_name" : "Guy bg",
        "name" : "Guy bg",
        "Column_2" : "",
        "SUID" : 498,
        "selected" : false
      },
      "position" : {
        "x" : 599.5937183561118,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "496",
        "shared_name" : "Menini",
        "name" : "Menini",
        "Column_2" : "",
        "SUID" : 496,
        "selected" : false
      },
      "position" : {
        "x" : 694.5937183561118,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "shared_name" : "Msita",
        "name" : "Msita",
        "Column_2" : "",
        "SUID" : 494,
        "selected" : false
      },
      "position" : {
        "x" : -512.5646149772228,
        "y" : 98.17670940893419
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "492",
        "shared_name" : "Scooter",
        "name" : "Scooter",
        "Column_2" : "",
        "SUID" : 492,
        "selected" : false
      },
      "position" : {
        "x" : 789.5937183561118,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "shared_name" : "Naran",
        "name" : "Naran",
        "Column_2" : "",
        "SUID" : 490,
        "selected" : false
      },
      "position" : {
        "x" : 2620.8812183561104,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "shared_name" : "Naraa",
        "name" : "Naraa",
        "Column_2" : "",
        "SUID" : 488,
        "selected" : false
      },
      "position" : {
        "x" : 124.59371835611182,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "486",
        "shared_name" : "06",
        "name" : "06",
        "Column_2" : "epTitle",
        "SUID" : 486,
        "selected" : false
      },
      "position" : {
        "x" : -1267.9851219216666,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "484",
        "shared_name" : "Isacco",
        "name" : "Isacco",
        "Column_2" : "",
        "SUID" : 484,
        "selected" : false
      },
      "position" : {
        "x" : -1505.4851219216662,
        "y" : -201.8232905910658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "shared_name" : "Pimp",
        "name" : "Pimp",
        "Column_2" : "",
        "SUID" : 482,
        "selected" : false
      },
      "position" : {
        "x" : 2145.8812183561104,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "480",
        "shared_name" : "Sfx",
        "name" : "Sfx",
        "Column_2" : "",
        "SUID" : 480,
        "selected" : false
      },
      "position" : {
        "x" : -650.4851219216662,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "shared_name" : "Bruno bg",
        "name" : "Bruno bg",
        "Column_2" : "",
        "SUID" : 478,
        "selected" : false
      },
      "position" : {
        "x" : -1125.4851219216662,
        "y" : -201.8232905910658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "shared_name" : "Sign top",
        "name" : "Sign top",
        "Column_2" : "",
        "SUID" : 476,
        "selected" : false
      },
      "position" : {
        "x" : 1582.0312183561118,
        "y" : 398.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "474",
        "shared_name" : "Sign bot",
        "name" : "Sign bot",
        "Column_2" : "",
        "SUID" : 474,
        "selected" : false
      },
      "position" : {
        "x" : 247.43538502277715,
        "y" : 98.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "472",
        "shared_name" : "Bzzzzzz,Sfx",
        "name" : "Bzzzzzz,Sfx",
        "Column_2" : "",
        "SUID" : 472,
        "selected" : false
      },
      "position" : {
        "x" : -1030.4851219216662,
        "y" : -201.8232905910658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "shared_name" : "Baaaaaa,Sfx",
        "name" : "Baaaaaa,Sfx",
        "Column_2" : "",
        "SUID" : 470,
        "selected" : false
      },
      "position" : {
        "x" : -1315.4851219216662,
        "y" : -201.8232905910658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "468",
        "shared_name" : "Fwip,Sfx",
        "name" : "Fwip,Sfx",
        "Column_2" : "",
        "SUID" : 468,
        "selected" : false
      },
      "position" : {
        "x" : -1220.4851219216662,
        "y" : -201.8232905910658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "466",
        "shared_name" : "Pop,Sfx",
        "name" : "Pop,Sfx",
        "Column_2" : "",
        "SUID" : 466,
        "selected" : false
      },
      "position" : {
        "x" : -1410.4851219216662,
        "y" : -201.8232905910658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "shared_name" : "07",
        "name" : "07",
        "Column_2" : "epTitle",
        "SUID" : 464,
        "selected" : false
      },
      "position" : {
        "x" : 2810.881218356112,
        "y" : 23.176709408934073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "462",
        "shared_name" : "Naranr",
        "name" : "Naranr",
        "Column_2" : "",
        "SUID" : 462,
        "selected" : false
      },
      "position" : {
        "x" : 2905.8812183561104,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "shared_name" : "Mist",
        "name" : "Mist",
        "Column_2" : "",
        "SUID" : 460,
        "selected" : false
      },
      "position" : {
        "x" : 3000.8812183561104,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "shared_name" : "B*llet",
        "name" : "B*llet",
        "Column_2" : "",
        "SUID" : 458,
        "selected" : false
      },
      "position" : {
        "x" : 152.43538502277715,
        "y" : 98.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "456",
        "shared_name" : "B*ll*ts",
        "name" : "B*ll*ts",
        "Column_2" : "",
        "SUID" : 456,
        "selected" : false
      },
      "position" : {
        "x" : 1549.59371835611,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "454",
        "shared_name" : "Menace,Sfx",
        "name" : "Menace,Sfx",
        "Column_2" : "",
        "SUID" : 454,
        "selected" : false
      },
      "position" : {
        "x" : 2810.8812183561104,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "shared_name" : "Bazoo,Sfx",
        "name" : "Bazoo,Sfx",
        "Column_2" : "",
        "SUID" : 452,
        "selected" : false
      },
      "position" : {
        "x" : 2715.8812183561104,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "shared_name" : "08",
        "name" : "08",
        "Column_2" : "epTitle",
        "SUID" : 450,
        "selected" : false
      },
      "position" : {
        "x" : -37.564614977222845,
        "y" : 23.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "shared_name" : "Six",
        "name" : "Six",
        "Column_2" : "",
        "SUID" : 448,
        "selected" : false
      },
      "position" : {
        "x" : -227.56461497722285,
        "y" : 98.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "shared_name" : "Thug",
        "name" : "Thug",
        "Column_2" : "",
        "SUID" : 446,
        "selected" : false
      },
      "position" : {
        "x" : 1310.7812183561118,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "shared_name" : "One",
        "name" : "One",
        "Column_2" : "",
        "SUID" : 444,
        "selected" : false
      },
      "position" : {
        "x" : 1826.4749683561104,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "442",
        "shared_name" : "Five",
        "name" : "Five",
        "Column_2" : "",
        "SUID" : 442,
        "selected" : false
      },
      "position" : {
        "x" : 57.435385022777155,
        "y" : 98.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "shared_name" : "Seven",
        "name" : "Seven",
        "Column_2" : "",
        "SUID" : 440,
        "selected" : false
      },
      "position" : {
        "x" : -132.56461497722285,
        "y" : 98.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "shared_name" : "All",
        "name" : "All",
        "Column_2" : "",
        "SUID" : 438,
        "selected" : false
      },
      "position" : {
        "x" : -322.56461497722285,
        "y" : 98.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "shared_name" : "09",
        "name" : "09",
        "Column_2" : "epTitle",
        "SUID" : 436,
        "selected" : false
      },
      "position" : {
        "x" : -460.4851219216662,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "shared_name" : "Trish",
        "name" : "Trish",
        "Column_2" : "",
        "SUID" : 434,
        "selected" : false
      },
      "position" : {
        "x" : -172.60979553277775,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "shared_name" : "Crack,Sfx",
        "name" : "Crack,Sfx",
        "Column_2" : "",
        "SUID" : 432,
        "selected" : false
      },
      "position" : {
        "x" : -365.4851219216662,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "shared_name" : "Peri",
        "name" : "Peri",
        "Column_2" : "",
        "SUID" : 430,
        "selected" : false
      },
      "position" : {
        "x" : -4246.735121921666,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "shared_name" : "Prei",
        "name" : "Prei",
        "Column_2" : "",
        "SUID" : 428,
        "selected" : false
      },
      "position" : {
        "x" : -270.4851219216662,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "426",
        "shared_name" : "Plop,Sfx",
        "name" : "Plop,Sfx",
        "Column_2" : "",
        "SUID" : 426,
        "selected" : false
      },
      "position" : {
        "x" : 314.5937183561109,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "shared_name" : "MistA",
        "name" : "MistA",
        "Column_2" : "",
        "SUID" : 424,
        "selected" : false
      },
      "position" : {
        "x" : -460.4851219216662,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "shared_name" : "Form",
        "name" : "Form",
        "Column_2" : "",
        "SUID" : 422,
        "selected" : false
      },
      "position" : {
        "x" : 1107.0312183561118,
        "y" : 398.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "shared_name" : "Find_them,Sign",
        "name" : "Find_them,Sign",
        "Column_2" : "",
        "SUID" : 420,
        "selected" : false
      },
      "position" : {
        "x" : -555.4851219216662,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "shared_name" : "10",
        "name" : "10",
        "Column_2" : "epTitle",
        "SUID" : 418,
        "selected" : false
      },
      "position" : {
        "x" : 1297.0312183561118,
        "y" : 323.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "shared_name" : "Narancia_s_Heigh,Sign",
        "name" : "Narancia_s_Heigh,Sign",
        "Column_2" : "",
        "SUID" : 416,
        "selected" : false
      },
      "position" : {
        "x" : -2170.4851219216666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "414",
        "shared_name" : "Formaggio",
        "name" : "Formaggio",
        "Column_2" : "",
        "SUID" : 414,
        "selected" : false
      },
      "position" : {
        "x" : 1392.0312183561118,
        "y" : 398.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "412",
        "shared_name" : "Pesci",
        "name" : "Pesci",
        "Column_2" : "",
        "SUID" : 412,
        "selected" : false
      },
      "position" : {
        "x" : 1012.0312183561118,
        "y" : 548.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "shared_name" : "Prosciutto",
        "name" : "Prosciutto",
        "Column_2" : "",
        "SUID" : 410,
        "selected" : false
      },
      "position" : {
        "x" : 1297.0312183561118,
        "y" : 398.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "shared_name" : "Pros",
        "name" : "Pros",
        "Column_2" : "",
        "SUID" : 408,
        "selected" : false
      },
      "position" : {
        "x" : 1487.0312183561118,
        "y" : 398.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "406",
        "shared_name" : "Risotto",
        "name" : "Risotto",
        "Column_2" : "",
        "SUID" : 406,
        "selected" : false
      },
      "position" : {
        "x" : 1202.0312183561118,
        "y" : 398.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "shared_name" : "Illuso",
        "name" : "Illuso",
        "Column_2" : "",
        "SUID" : 404,
        "selected" : false
      },
      "position" : {
        "x" : 1439.5312183561118,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "shared_name" : "Ghiaccio",
        "name" : "Ghiaccio",
        "Column_2" : "",
        "SUID" : 402,
        "selected" : false
      },
      "position" : {
        "x" : 1955.8812183561104,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "400",
        "shared_name" : "Melone",
        "name" : "Melone",
        "Column_2" : "",
        "SUID" : 400,
        "selected" : false
      },
      "position" : {
        "x" : 1765.8812183561104,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "shared_name" : "Ghiacchio",
        "name" : "Ghiacchio",
        "Column_2" : "",
        "SUID" : 398,
        "selected" : false
      },
      "position" : {
        "x" : 1215.7812183561118,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "shared_name" : "Ghia",
        "name" : "Ghia",
        "Column_2" : "",
        "SUID" : 396,
        "selected" : false
      },
      "position" : {
        "x" : 1107.0312183561118,
        "y" : 548.1767094089339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "shared_name" : "11",
        "name" : "11",
        "Column_2" : "epTitle",
        "SUID" : 394,
        "selected" : false
      },
      "position" : {
        "x" : -2075.4851219216666,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "shared_name" : "Blonde",
        "name" : "Blonde",
        "Column_2" : "",
        "SUID" : 392,
        "selected" : false
      },
      "position" : {
        "x" : 2050.8812183561104,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "shared_name" : "12",
        "name" : "12",
        "Column_2" : "epTitle",
        "SUID" : 390,
        "selected" : false
      },
      "position" : {
        "x" : 1582.0312183561118,
        "y" : 323.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "shared_name" : "Illu",
        "name" : "Illu",
        "Column_2" : "",
        "SUID" : 388,
        "selected" : false
      },
      "position" : {
        "x" : 599.5937183561109,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "shared_name" : "13",
        "name" : "13",
        "Column_2" : "epTitle",
        "SUID" : 386,
        "selected" : false
      },
      "position" : {
        "x" : 1070.534343356111,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "shared_name" : "Gior",
        "name" : "Gior",
        "Column_2" : "",
        "SUID" : 384,
        "selected" : false
      },
      "position" : {
        "x" : 1264.59371835611,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "shared_name" : "14",
        "name" : "14",
        "Column_2" : "epTitle",
        "SUID" : 382,
        "selected" : false
      },
      "position" : {
        "x" : -91.859142755,
        "y" : -126.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "shared_name" : "Pro",
        "name" : "Pro",
        "Column_2" : "",
        "SUID" : 380,
        "selected" : false
      },
      "position" : {
        "x" : 869.5312183561118,
        "y" : 698.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "shared_name" : "15",
        "name" : "15",
        "Column_2" : "epTitle",
        "SUID" : 378,
        "selected" : false
      },
      "position" : {
        "x" : 219.5937183561109,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "shared_name" : "Two",
        "name" : "Two",
        "Column_2" : "",
        "SUID" : 376,
        "selected" : false
      },
      "position" : {
        "x" : 1359.59371835611,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "shared_name" : "Three",
        "name" : "Three",
        "Column_2" : "",
        "SUID" : 374,
        "selected" : false
      },
      "position" : {
        "x" : 1823.331218356111,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "shared_name" : "Misa",
        "name" : "Misa",
        "Column_2" : "",
        "SUID" : 372,
        "selected" : false
      },
      "position" : {
        "x" : 219.5937183561109,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "shared_name" : "16",
        "name" : "16",
        "Column_2" : "epTitle",
        "SUID" : 370,
        "selected" : false
      },
      "position" : {
        "x" : 1012.0312183561118,
        "y" : 623.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "shared_name" : "Borgh,Sfx",
        "name" : "Borgh,Sfx",
        "Column_2" : "",
        "SUID" : 368,
        "selected" : false
      },
      "position" : {
        "x" : 1059.5312183561118,
        "y" : 698.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "shared_name" : "Goodbye_,Sign",
        "name" : "Goodbye_,Sign",
        "Column_2" : "",
        "SUID" : 366,
        "selected" : false
      },
      "position" : {
        "x" : 1154.5312183561118,
        "y" : 698.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "364",
        "shared_name" : "Prosciutto____De,Sign",
        "name" : "Prosciutto____De,Sign",
        "Column_2" : "",
        "SUID" : 364,
        "selected" : false
      },
      "position" : {
        "x" : 964.5312183561118,
        "y" : 698.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "shared_name" : "Phone",
        "name" : "Phone",
        "Column_2" : "",
        "SUID" : 362,
        "selected" : false
      },
      "position" : {
        "x" : -3025.485121921666,
        "y" : -201.8232905910658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "shared_name" : "17",
        "name" : "17",
        "Column_2" : "epTitle",
        "SUID" : 360,
        "selected" : false
      },
      "position" : {
        "x" : -3025.485121921666,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "shared_name" : "Anita",
        "name" : "Anita",
        "Column_2" : "",
        "SUID" : 358,
        "selected" : false
      },
      "position" : {
        "x" : -2930.485121921666,
        "y" : -201.8232905910658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "shared_name" : "Smack,Sfx",
        "name" : "Smack,Sfx",
        "Column_2" : "",
        "SUID" : 356,
        "selected" : false
      },
      "position" : {
        "x" : -3120.485121921666,
        "y" : -201.8232905910658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "shared_name" : "Baby",
        "name" : "Baby",
        "Column_2" : "",
        "SUID" : 354,
        "selected" : false
      },
      "position" : {
        "x" : 1454.59371835611,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "shared_name" : "18",
        "name" : "18",
        "Column_2" : "epTitle",
        "SUID" : 352,
        "selected" : false
      },
      "position" : {
        "x" : 1826.4749683561104,
        "y" : -126.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "shared_name" : "Riso",
        "name" : "Riso",
        "Column_2" : "",
        "SUID" : 350,
        "selected" : false
      },
      "position" : {
        "x" : 1644.59371835611,
        "y" : -51.82329059106593
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "shared_name" : "GW",
        "name" : "GW",
        "Column_2" : "",
        "SUID" : 348,
        "selected" : false
      },
      "position" : {
        "x" : 3190.8812183561104,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "shared_name" : "Crush,Sfx",
        "name" : "Crush,Sfx",
        "Column_2" : "",
        "SUID" : 346,
        "selected" : false
      },
      "position" : {
        "x" : 1739.59371835611,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "shared_name" : "Dia",
        "name" : "Dia",
        "Column_2" : "",
        "SUID" : 344,
        "selected" : false
      },
      "position" : {
        "x" : -2360.4851219216666,
        "y" : -51.82329059106593
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "shared_name" : "19",
        "name" : "19",
        "Column_2" : "epTitle",
        "SUID" : 342,
        "selected" : false
      },
      "position" : {
        "x" : -2360.4851219216666,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "shared_name" : "Both",
        "name" : "Both",
        "Column_2" : "",
        "SUID" : 340,
        "selected" : false
      },
      "position" : {
        "x" : -2360.4851219216666,
        "y" : -201.82329059106593
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "shared_name" : "Guard",
        "name" : "Guard",
        "Column_2" : "",
        "SUID" : 338,
        "selected" : false
      },
      "position" : {
        "x" : -2455.4851219216666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "shared_name" : "Risotto_s_wherea,Sign",
        "name" : "Risotto_s_wherea,Sign",
        "Column_2" : "",
        "SUID" : 336,
        "selected" : false
      },
      "position" : {
        "x" : -2265.4851219216666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "shared_name" : "Boss",
        "name" : "Boss",
        "Column_2" : "",
        "SUID" : 334,
        "selected" : false
      },
      "position" : {
        "x" : 1670.8812183561104,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "shared_name" : "20",
        "name" : "20",
        "Column_2" : "epTitle",
        "SUID" : 332,
        "selected" : false
      },
      "position" : {
        "x" : -253.3604483105555,
        "y" : -126.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "shared_name" : "Nurse",
        "name" : "Nurse",
        "Column_2" : "",
        "SUID" : 330,
        "selected" : false
      },
      "position" : {
        "x" : -65.40628164388909,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "shared_name" : "Punk",
        "name" : "Punk",
        "Column_2" : "",
        "SUID" : 328,
        "selected" : false
      },
      "position" : {
        "x" : -160.40628164389,
        "y" : -51.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "shared_name" : "21",
        "name" : "21",
        "Column_2" : "epTitle",
        "SUID" : 326,
        "selected" : false
      },
      "position" : {
        "x" : 1728.331218356111,
        "y" : 173.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "shared_name" : "Burno",
        "name" : "Burno",
        "Column_2" : "",
        "SUID" : 324,
        "selected" : false
      },
      "position" : {
        "x" : 2240.8812183561104,
        "y" : 248.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "shared_name" : "Doppio",
        "name" : "Doppio",
        "Column_2" : "",
        "SUID" : 322,
        "selected" : false
      },
      "position" : {
        "x" : 1158.331218356111,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "shared_name" : "22",
        "name" : "22",
        "Column_2" : "epTitle",
        "SUID" : 320,
        "selected" : false
      },
      "position" : {
        "x" : 1870.831218356111,
        "y" : 23.176709408934073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "shared_name" : "Squalo",
        "name" : "Squalo",
        "Column_2" : "",
        "SUID" : 318,
        "selected" : false
      },
      "position" : {
        "x" : -2550.485121921666,
        "y" : -201.82329059106547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "shared_name" : "Tiziano",
        "name" : "Tiziano",
        "Column_2" : "",
        "SUID" : 316,
        "selected" : false
      },
      "position" : {
        "x" : -2645.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "shared_name" : "Aba",
        "name" : "Aba",
        "Column_2" : "",
        "SUID" : 314,
        "selected" : false
      },
      "position" : {
        "x" : 2013.331218356111,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "shared_name" : "Giono",
        "name" : "Giono",
        "Column_2" : "",
        "SUID" : 312,
        "selected" : false
      },
      "position" : {
        "x" : 1918.331218356111,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "shared_name" : "23",
        "name" : "23",
        "Column_2" : "epTitle",
        "SUID" : 310,
        "selected" : false
      },
      "position" : {
        "x" : -2692.9851219216666,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "shared_name" : "Tizi",
        "name" : "Tizi",
        "Column_2" : "",
        "SUID" : 308,
        "selected" : false
      },
      "position" : {
        "x" : -2740.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "shared_name" : "Rome___a_m_,Nara",
        "name" : "Rome___a_m_,Nara",
        "Column_2" : "",
        "SUID" : 306,
        "selected" : false
      },
      "position" : {
        "x" : -2835.485121921666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "shared_name" : "24",
        "name" : "24",
        "Column_2" : "epTitle",
        "SUID" : 304,
        "selected" : false
      },
      "position" : {
        "x" : 152.43538502277715,
        "y" : 173.1767094089344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "shared_name" : "GIO",
        "name" : "GIO",
        "Column_2" : "",
        "SUID" : 302,
        "selected" : false
      },
      "position" : {
        "x" : 152.43538502277715,
        "y" : 248.1767094089344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "shared_name" : "Runo",
        "name" : "Runo",
        "Column_2" : "",
        "SUID" : 300,
        "selected" : false
      },
      "position" : {
        "x" : 247.43538502277715,
        "y" : 248.1767094089344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "shared_name" : "Tirsh",
        "name" : "Tirsh",
        "Column_2" : "",
        "SUID" : 298,
        "selected" : false
      },
      "position" : {
        "x" : 57.435385022777155,
        "y" : 248.1767094089344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "shared_name" : "25",
        "name" : "25",
        "Column_2" : "epTitle",
        "SUID" : 296,
        "selected" : false
      },
      "position" : {
        "x" : -121.51878159759235,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "shared_name" : "Spice",
        "name" : "Spice",
        "Column_2" : "",
        "SUID" : 294,
        "selected" : false
      },
      "position" : {
        "x" : -121.51878159759235,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "shared_name" : "Spicy",
        "name" : "Spicy",
        "Column_2" : "",
        "SUID" : 292,
        "selected" : false
      },
      "position" : {
        "x" : -70.42776766240695,
        "y" : -201.82329059106576
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "shared_name" : "Diavolo",
        "name" : "Diavolo",
        "Column_2" : "",
        "SUID" : 290,
        "selected" : false
      },
      "position" : {
        "x" : 3285.8812183561104,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "shared_name" : "26",
        "name" : "26",
        "Column_2" : "epTitle",
        "SUID" : 288,
        "selected" : false
      },
      "position" : {
        "x" : 1300.831218356111,
        "y" : 23.176709408933846
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "shared_name" : "Inmate",
        "name" : "Inmate",
        "Column_2" : "",
        "SUID" : 286,
        "selected" : false
      },
      "position" : {
        "x" : 1348.331218356111,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "shared_name" : "Inamate",
        "name" : "Inamate",
        "Column_2" : "",
        "SUID" : 284,
        "selected" : false
      },
      "position" : {
        "x" : 1443.331218356111,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "shared_name" : "Man",
        "name" : "Man",
        "Column_2" : "",
        "SUID" : 282,
        "selected" : false
      },
      "position" : {
        "x" : 1063.331218356111,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "shared_name" : "Priest",
        "name" : "Priest",
        "Column_2" : "",
        "SUID" : 280,
        "selected" : false
      },
      "position" : {
        "x" : 1538.331218356111,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "shared_name" : "Boy",
        "name" : "Boy",
        "Column_2" : "",
        "SUID" : 278,
        "selected" : false
      },
      "position" : {
        "x" : 1633.331218356111,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "shared_name" : "Taxi",
        "name" : "Taxi",
        "Column_2" : "",
        "SUID" : 276,
        "selected" : false
      },
      "position" : {
        "x" : 1253.331218356111,
        "y" : 98.17670940893385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "shared_name" : "27",
        "name" : "27",
        "Column_2" : "epTitle",
        "SUID" : 274,
        "selected" : false
      },
      "position" : {
        "x" : 1107.0312183561118,
        "y" : 473.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "shared_name" : "Dopp",
        "name" : "Dopp",
        "Column_2" : "",
        "SUID" : 272,
        "selected" : false
      },
      "position" : {
        "x" : 1202.0312183561118,
        "y" : 548.1767094089341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "shared_name" : "28",
        "name" : "28",
        "Column_2" : "epTitle",
        "SUID" : 270,
        "selected" : false
      },
      "position" : {
        "x" : -1800.8355455327774,
        "y" : -426.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "shared_name" : "Rios",
        "name" : "Rios",
        "Column_2" : "",
        "SUID" : 268,
        "selected" : false
      },
      "position" : {
        "x" : -26.51878159759235,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "shared_name" : "Dop",
        "name" : "Dop",
        "Column_2" : "",
        "SUID" : 266,
        "selected" : false
      },
      "position" : {
        "x" : -849.5232330327772,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "shared_name" : "",
        "name" : "",
        "Column_2" : "",
        "SUID" : 264,
        "selected" : false
      },
      "position" : {
        "x" : 68.48121840240765,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "shared_name" : "Setting",
        "name" : "Setting",
        "Column_2" : "",
        "SUID" : 262,
        "selected" : false
      },
      "position" : {
        "x" : 163.48121840240765,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "shared_name" : "What_the_hell_is",
        "name" : "What_the_hell_is",
        "Column_2" : "",
        "SUID" : 260,
        "selected" : false
      },
      "position" : {
        "x" : 258.48121840240765,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "shared_name" : "What_the_hell_is,Fugo",
        "name" : "What_the_hell_is,Fugo",
        "Column_2" : "",
        "SUID" : 258,
        "selected" : false
      },
      "position" : {
        "x" : -754.5232330327772,
        "y" : -351.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "shared_name" : "29",
        "name" : "29",
        "Column_2" : "epTitle",
        "SUID" : 256,
        "selected" : false
      },
      "position" : {
        "x" : 2430.881218356112,
        "y" : 173.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "shared_name" : "Drunk",
        "name" : "Drunk",
        "Column_2" : "",
        "SUID" : 254,
        "selected" : false
      },
      "position" : {
        "x" : 2430.881218356112,
        "y" : 248.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "shared_name" : "Cio",
        "name" : "Cio",
        "Column_2" : "",
        "SUID" : 252,
        "selected" : false
      },
      "position" : {
        "x" : 2430.881218356112,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "shared_name" : "Eulogy_Predicts_ - Copy,Sign",
        "name" : "Eulogy_Predicts_ - Copy,Sign",
        "Column_2" : "",
        "SUID" : 250,
        "selected" : false
      },
      "position" : {
        "x" : 2525.881218356112,
        "y" : 248.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "shared_name" : "Eulogy_Predicts_,Sign",
        "name" : "Eulogy_Predicts_,Sign",
        "Column_2" : "",
        "SUID" : 248,
        "selected" : false
      },
      "position" : {
        "x" : 2335.881218356112,
        "y" : 248.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "shared_name" : "Crunch,Sign",
        "name" : "Crunch,Sign",
        "Column_2" : "",
        "SUID" : 246,
        "selected" : false
      },
      "position" : {
        "x" : -2407.9851219216666,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "shared_name" : "30",
        "name" : "30",
        "Column_2" : "epTitle",
        "SUID" : 244,
        "selected" : false
      },
      "position" : {
        "x" : -840.4851219216666,
        "y" : -276.8232905910655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "shared_name" : "Zip",
        "name" : "Zip",
        "Column_2" : "",
        "SUID" : 242,
        "selected" : false
      },
      "position" : {
        "x" : -745.4851219216662,
        "y" : -201.82329059106547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "shared_name" : "Secco",
        "name" : "Secco",
        "Column_2" : "",
        "SUID" : 240,
        "selected" : false
      },
      "position" : {
        "x" : -840.4851219216666,
        "y" : -201.82329059106547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "shared_name" : "Giio",
        "name" : "Giio",
        "Column_2" : "",
        "SUID" : 238,
        "selected" : false
      },
      "position" : {
        "x" : -935.4851219216666,
        "y" : -201.82329059106547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "shared_name" : "31",
        "name" : "31",
        "Column_2" : "epTitle",
        "SUID" : 236,
        "selected" : false
      },
      "position" : {
        "x" : -297.85178858833297,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "shared_name" : "32",
        "name" : "32",
        "Column_2" : "epTitle",
        "SUID" : 234,
        "selected" : false
      },
      "position" : {
        "x" : 2478.381218356112,
        "y" : 23.176709408934073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "shared_name" : "Pol",
        "name" : "Pol",
        "Column_2" : "",
        "SUID" : 232,
        "selected" : false
      },
      "position" : {
        "x" : -607.5646149772228,
        "y" : 98.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "shared_name" : "J_P__Polnareff__,Sign",
        "name" : "J_P__Polnareff__,Sign",
        "Column_2" : "",
        "SUID" : 230,
        "selected" : false
      },
      "position" : {
        "x" : 2525.881218356112,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "shared_name" : "33",
        "name" : "33",
        "Column_2" : "epTitle",
        "SUID" : 228,
        "selected" : false
      },
      "position" : {
        "x" : -2360.4851219216666,
        "y" : -126.82329059106593
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "shared_name" : "34",
        "name" : "34",
        "Column_2" : "epTitle",
        "SUID" : 226,
        "selected" : false
      },
      "position" : {
        "x" : -2360.4851219216666,
        "y" : 23.176709408934073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "shared_name" : "No_one_can_escap,Op subs",
        "name" : "No_one_can_escap,Op subs",
        "Column_2" : "",
        "SUID" : 224,
        "selected" : false
      },
      "position" : {
        "x" : -797.5646149772233,
        "y" : 98.17670940893419
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "shared_name" : "Turtle",
        "name" : "Turtle",
        "Column_2" : "",
        "SUID" : 222,
        "selected" : false
      },
      "position" : {
        "x" : -1790.4851219216666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "shared_name" : "Who_swapped_with,Sign",
        "name" : "Who_swapped_with,Sign",
        "Column_2" : "",
        "SUID" : 220,
        "selected" : false
      },
      "position" : {
        "x" : -2312.9851219216666,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "shared_name" : "Mista___________,Sign",
        "name" : "Mista___________,Sign",
        "Column_2" : "",
        "SUID" : 218,
        "selected" : false
      },
      "position" : {
        "x" : -2217.9851219216666,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "shared_name" : "Turtrle",
        "name" : "Turtrle",
        "Column_2" : "",
        "SUID" : 216,
        "selected" : false
      },
      "position" : {
        "x" : -2502.9851219216666,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "shared_name" : "35",
        "name" : "35",
        "Column_2" : "epTitle",
        "SUID" : 214,
        "selected" : false
      },
      "position" : {
        "x" : -1742.9851219216666,
        "y" : -276.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "shared_name" : "Dog",
        "name" : "Dog",
        "Column_2" : "",
        "SUID" : 212,
        "selected" : false
      },
      "position" : {
        "x" : -1695.4851219216666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "shared_name" : "Narancia",
        "name" : "Narancia",
        "Column_2" : "",
        "SUID" : 210,
        "selected" : false
      },
      "position" : {
        "x" : -1600.4851219216666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "shared_name" : "Crunch,Trish",
        "name" : "Crunch,Trish",
        "Column_2" : "",
        "SUID" : 208,
        "selected" : false
      },
      "position" : {
        "x" : -1885.4851219216666,
        "y" : -201.8232905910657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "shared_name" : "36",
        "name" : "36",
        "Column_2" : "epTitle",
        "SUID" : 206,
        "selected" : false
      },
      "position" : {
        "x" : 3095.8812183561104,
        "y" : 173.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "shared_name" : "King",
        "name" : "King",
        "Column_2" : "",
        "SUID" : 204,
        "selected" : false
      },
      "position" : {
        "x" : 3095.8812183561104,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "shared_name" : "Who_swapped_with,King",
        "name" : "Who_swapped_with,King",
        "Column_2" : "",
        "SUID" : 202,
        "selected" : false
      },
      "position" : {
        "x" : 3095.881218356112,
        "y" : 248.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "shared_name" : "Bucciarati,Sign",
        "name" : "Bucciarati,Sign",
        "Column_2" : "",
        "SUID" : 200,
        "selected" : false
      },
      "position" : {
        "x" : 3190.8812183561104,
        "y" : 248.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "shared_name" : "Bull",
        "name" : "Bull",
        "Column_2" : "",
        "SUID" : 198,
        "selected" : false
      },
      "position" : {
        "x" : 3000.881218356112,
        "y" : 248.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "shared_name" : "37",
        "name" : "37",
        "Column_2" : "epTitle",
        "SUID" : 196,
        "selected" : false
      },
      "position" : {
        "x" : 3285.881218356112,
        "y" : 23.176709408934073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "shared_name" : "Crunch,sfx",
        "name" : "Crunch,sfx",
        "Column_2" : "",
        "SUID" : 194,
        "selected" : false
      },
      "position" : {
        "x" : 3380.8812183561104,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "shared_name" : "Gw",
        "name" : "Gw",
        "Column_2" : "",
        "SUID" : 192,
        "selected" : false
      },
      "position" : {
        "x" : 3475.8812183561104,
        "y" : 98.17670940893407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "shared_name" : "38",
        "name" : "38",
        "Column_2" : "epTitle",
        "SUID" : 190,
        "selected" : false
      },
      "position" : {
        "x" : -845.0646149772233,
        "y" : 23.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "shared_name" : "Bad_luck,Sign",
        "name" : "Bad_luck,Sign",
        "Column_2" : "",
        "SUID" : 188,
        "selected" : false
      },
      "position" : {
        "x" : -892.5646149772233,
        "y" : 98.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "shared_name" : "39",
        "name" : "39",
        "Column_2" : "epTitle",
        "SUID" : 186,
        "selected" : false
      },
      "position" : {
        "x" : -560.0646149772228,
        "y" : 23.1767094089343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "shared_name" : "Op subs",
        "name" : "Op subs",
        "Column_2" : "",
        "SUID" : 184,
        "selected" : false
      },
      "position" : {
        "x" : -417.56461497722285,
        "y" : 98.17670940893419
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "shared_name" : "Sco",
        "name" : "Sco",
        "Column_2" : "",
        "SUID" : 182,
        "selected" : false
      },
      "position" : {
        "x" : -702.5646149772228,
        "y" : 98.17670940893419
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1968",
        "source" : "608",
        "target" : "606",
        "shared_name" : "01 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1968,
        "Column_4" : 23,
        "BEND_MAP_ID" : 1968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1966",
        "source" : "608",
        "target" : "604",
        "shared_name" : "01 (interacts with) Girl",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Girl",
        "interaction" : "interacts with",
        "SUID" : 1966,
        "Column_4" : 22,
        "BEND_MAP_ID" : 1966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1964",
        "source" : "608",
        "target" : "602",
        "shared_name" : "01 (interacts with) Cop",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Cop",
        "interaction" : "interacts with",
        "SUID" : 1964,
        "Column_4" : 16,
        "BEND_MAP_ID" : 1964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1962",
        "source" : "608",
        "target" : "600",
        "shared_name" : "01 (interacts with) Kid",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Kid",
        "interaction" : "interacts with",
        "SUID" : 1962,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1960",
        "source" : "608",
        "target" : "598",
        "shared_name" : "01 (interacts with) Girls",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Girls",
        "interaction" : "interacts with",
        "SUID" : 1960,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1958",
        "source" : "608",
        "target" : "596",
        "shared_name" : "01 (interacts with) Creep",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Creep",
        "interaction" : "interacts with",
        "SUID" : 1958,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1956",
        "source" : "608",
        "target" : "594",
        "shared_name" : "01 (interacts with) Driver",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Driver",
        "interaction" : "interacts with",
        "SUID" : 1956,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1954",
        "source" : "608",
        "target" : "592",
        "shared_name" : "01 (interacts with) Luca",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Luca",
        "interaction" : "interacts with",
        "SUID" : 1954,
        "Column_4" : 40,
        "BEND_MAP_ID" : 1954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1952",
        "source" : "608",
        "target" : "590",
        "shared_name" : "01 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1952,
        "Column_4" : 88,
        "BEND_MAP_ID" : 1952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1950",
        "source" : "608",
        "target" : "588",
        "shared_name" : "01 (interacts with) Koichi",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Koichi",
        "interaction" : "interacts with",
        "SUID" : 1950,
        "Column_4" : 90,
        "BEND_MAP_ID" : 1950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1948",
        "source" : "608",
        "target" : "586",
        "shared_name" : "01 (interacts with) Whack,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Whack,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1948,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1946",
        "source" : "608",
        "target" : "584",
        "shared_name" : "01 (interacts with) Jotaro",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Jotaro",
        "interaction" : "interacts with",
        "SUID" : 1946,
        "Column_4" : 25,
        "BEND_MAP_ID" : 1946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1944",
        "source" : "608",
        "target" : "582",
        "shared_name" : "01 (interacts with) Act",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Act",
        "interaction" : "interacts with",
        "SUID" : 1944,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1942",
        "source" : "608",
        "target" : "580",
        "shared_name" : "01 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1942,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1940",
        "source" : "608",
        "target" : "578",
        "shared_name" : "01 (interacts with) Glob",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Glob",
        "interaction" : "interacts with",
        "SUID" : 1940,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1938",
        "source" : "608",
        "target" : "576",
        "shared_name" : "01 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "01 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1938,
        "Column_4" : 57,
        "BEND_MAP_ID" : 1938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1936",
        "source" : "574",
        "target" : "604",
        "shared_name" : "02 (interacts with) Girl",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Girl",
        "interaction" : "interacts with",
        "SUID" : 1936,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1934",
        "source" : "574",
        "target" : "572",
        "shared_name" : "02 (interacts with) Mom",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Mom",
        "interaction" : "interacts with",
        "SUID" : 1934,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1932",
        "source" : "574",
        "target" : "570",
        "shared_name" : "02 (interacts with) Shiobana,Sign",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Shiobana,Sign",
        "interaction" : "interacts with",
        "SUID" : 1932,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1930",
        "source" : "574",
        "target" : "606",
        "shared_name" : "02 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1930,
        "Column_4" : 29,
        "BEND_MAP_ID" : 1930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1928",
        "source" : "574",
        "target" : "568",
        "shared_name" : "02 (interacts with) Dad",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Dad",
        "interaction" : "interacts with",
        "SUID" : 1928,
        "Column_4" : 11,
        "BEND_MAP_ID" : 1928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1926",
        "source" : "574",
        "target" : "600",
        "shared_name" : "02 (interacts with) Kid",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Kid",
        "interaction" : "interacts with",
        "SUID" : 1926,
        "Column_4" : 16,
        "BEND_MAP_ID" : 1926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1924",
        "source" : "574",
        "target" : "566",
        "shared_name" : "02 (interacts with) Popo",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Popo",
        "interaction" : "interacts with",
        "SUID" : 1924,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1922",
        "source" : "574",
        "target" : "564",
        "shared_name" : "02 (interacts with) Kids",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Kids",
        "interaction" : "interacts with",
        "SUID" : 1922,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1920",
        "source" : "574",
        "target" : "590",
        "shared_name" : "02 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1920,
        "Column_4" : 94,
        "BEND_MAP_ID" : 1920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1918",
        "source" : "574",
        "target" : "562",
        "shared_name" : "02 (interacts with) X",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) X",
        "interaction" : "interacts with",
        "SUID" : 1918,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1916",
        "source" : "574",
        "target" : "560",
        "shared_name" : "02 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1916,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1914",
        "source" : "574",
        "target" : "576",
        "shared_name" : "02 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1914,
        "Column_4" : 92,
        "BEND_MAP_ID" : 1914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1912",
        "source" : "574",
        "target" : "558",
        "shared_name" : "02 (interacts with) Gold",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Gold",
        "interaction" : "interacts with",
        "SUID" : 1912,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1910",
        "source" : "574",
        "target" : "556",
        "shared_name" : "02 (interacts with) Bagyah,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Bagyah,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1910,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1908",
        "source" : "574",
        "target" : "554",
        "shared_name" : "02 (interacts with) Rumble,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Rumble,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1908,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1906",
        "source" : "574",
        "target" : "552",
        "shared_name" : "02 (interacts with) Whoosh,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Whoosh,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1906,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1904",
        "source" : "574",
        "target" : "550",
        "shared_name" : "02 (interacts with) Boom,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Boom,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1904,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1902",
        "source" : "574",
        "target" : "580",
        "shared_name" : "02 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1902,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1900",
        "source" : "574",
        "target" : "548",
        "shared_name" : "02 (interacts with) Kabaam,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Kabaam,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1900,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1898",
        "source" : "574",
        "target" : "546",
        "shared_name" : "02 (interacts with) Guy C",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Guy C",
        "interaction" : "interacts with",
        "SUID" : 1898,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1896",
        "source" : "574",
        "target" : "544",
        "shared_name" : "02 (interacts with) Jump,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Jump,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1896,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1894",
        "source" : "574",
        "target" : "542",
        "shared_name" : "02 (interacts with) Thud,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "02 (interacts with) Thud,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1894,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1894,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1892",
        "source" : "540",
        "target" : "590",
        "shared_name" : "03 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1892,
        "Column_4" : 100,
        "BEND_MAP_ID" : 1892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1890",
        "source" : "540",
        "target" : "576",
        "shared_name" : "03 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1890,
        "Column_4" : 33,
        "BEND_MAP_ID" : 1890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1888",
        "source" : "540",
        "target" : "600",
        "shared_name" : "03 (interacts with) Kid",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Kid",
        "interaction" : "interacts with",
        "SUID" : 1888,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1886",
        "source" : "540",
        "target" : "564",
        "shared_name" : "03 (interacts with) Kids",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Kids",
        "interaction" : "interacts with",
        "SUID" : 1886,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1884",
        "source" : "540",
        "target" : "538",
        "shared_name" : "03 (interacts with) Loom,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Loom,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1884,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1882",
        "source" : "540",
        "target" : "602",
        "shared_name" : "03 (interacts with) Cop",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Cop",
        "interaction" : "interacts with",
        "SUID" : 1882,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1880",
        "source" : "540",
        "target" : "560",
        "shared_name" : "03 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1880,
        "Column_4" : 24,
        "BEND_MAP_ID" : 1880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1878",
        "source" : "540",
        "target" : "536",
        "shared_name" : "03 (interacts with) Polpo",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Polpo",
        "interaction" : "interacts with",
        "SUID" : 1878,
        "Column_4" : 49,
        "BEND_MAP_ID" : 1878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1876",
        "source" : "540",
        "target" : "580",
        "shared_name" : "03 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1876,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1874",
        "source" : "540",
        "target" : "606",
        "shared_name" : "03 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1874,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1872",
        "source" : "540",
        "target" : "534",
        "shared_name" : "03 (interacts with) Old",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Old",
        "interaction" : "interacts with",
        "SUID" : 1872,
        "Column_4" : 18,
        "BEND_MAP_ID" : 1872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1870",
        "source" : "540",
        "target" : "588",
        "shared_name" : "03 (interacts with) Koichi",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Koichi",
        "interaction" : "interacts with",
        "SUID" : 1870,
        "Column_4" : 14,
        "BEND_MAP_ID" : 1870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1868",
        "source" : "540",
        "target" : "552",
        "shared_name" : "03 (interacts with) Whoosh,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Whoosh,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1868,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1866",
        "source" : "540",
        "target" : "532",
        "shared_name" : "03 (interacts with) Black",
        "shared_interaction" : "interacts with",
        "name" : "03 (interacts with) Black",
        "interaction" : "interacts with",
        "SUID" : 1866,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1864",
        "source" : "530",
        "target" : "590",
        "shared_name" : "04 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1864,
        "Column_4" : 122,
        "BEND_MAP_ID" : 1864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1862",
        "source" : "530",
        "target" : "532",
        "shared_name" : "04 (interacts with) Black",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Black",
        "interaction" : "interacts with",
        "SUID" : 1862,
        "Column_4" : 15,
        "BEND_MAP_ID" : 1862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1860",
        "source" : "530",
        "target" : "528",
        "shared_name" : "04 (interacts with) Girono",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Girono",
        "interaction" : "interacts with",
        "SUID" : 1860,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1858",
        "source" : "530",
        "target" : "588",
        "shared_name" : "04 (interacts with) Koichi",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Koichi",
        "interaction" : "interacts with",
        "SUID" : 1858,
        "Column_4" : 83,
        "BEND_MAP_ID" : 1858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1856",
        "source" : "530",
        "target" : "526",
        "shared_name" : "04 (interacts with) Reverb",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Reverb",
        "interaction" : "interacts with",
        "SUID" : 1856,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1854",
        "source" : "530",
        "target" : "524",
        "shared_name" : "04 (interacts with) Bam,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Bam,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1854,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1852",
        "source" : "530",
        "target" : "580",
        "shared_name" : "04 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1852,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1850",
        "source" : "530",
        "target" : "522",
        "shared_name" : "04 (interacts with) The_Next_Day,Sign",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) The_Next_Day,Sign",
        "interaction" : "interacts with",
        "SUID" : 1850,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1848",
        "source" : "530",
        "target" : "536",
        "shared_name" : "04 (interacts with) Polpo",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Polpo",
        "interaction" : "interacts with",
        "SUID" : 1848,
        "Column_4" : 35,
        "BEND_MAP_ID" : 1848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1846",
        "source" : "530",
        "target" : "584",
        "shared_name" : "04 (interacts with) Jotaro",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Jotaro",
        "interaction" : "interacts with",
        "SUID" : 1846,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1844",
        "source" : "530",
        "target" : "576",
        "shared_name" : "04 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "04 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1844,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1842",
        "source" : "520",
        "target" : "576",
        "shared_name" : "05 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1842,
        "Column_4" : 115,
        "BEND_MAP_ID" : 1842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1840",
        "source" : "520",
        "target" : "606",
        "shared_name" : "05 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1840,
        "Column_4" : 16,
        "BEND_MAP_ID" : 1840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1838",
        "source" : "520",
        "target" : "604",
        "shared_name" : "05 (interacts with) Girl",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Girl",
        "interaction" : "interacts with",
        "SUID" : 1838,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1836",
        "source" : "520",
        "target" : "580",
        "shared_name" : "05 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1836,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1834",
        "source" : "520",
        "target" : "518",
        "shared_name" : "05 (interacts with) Sale",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Sale",
        "interaction" : "interacts with",
        "SUID" : 1834,
        "Column_4" : 37,
        "BEND_MAP_ID" : 1834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1832",
        "source" : "520",
        "target" : "516",
        "shared_name" : "05 (interacts with) Mario",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Mario",
        "interaction" : "interacts with",
        "SUID" : 1832,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1830",
        "source" : "520",
        "target" : "514",
        "shared_name" : "05 (interacts with) Rome___a_m_,Sign",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Rome___a_m_,Sign",
        "interaction" : "interacts with",
        "SUID" : 1830,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1828",
        "source" : "520",
        "target" : "512",
        "shared_name" : "05 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1828,
        "Column_4" : 34,
        "BEND_MAP_ID" : 1828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1826",
        "source" : "520",
        "target" : "510",
        "shared_name" : "05 (interacts with) Waiter",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Waiter",
        "interaction" : "interacts with",
        "SUID" : 1826,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1824",
        "source" : "520",
        "target" : "508",
        "shared_name" : "05 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1824,
        "Column_4" : 44,
        "BEND_MAP_ID" : 1824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1822",
        "source" : "520",
        "target" : "506",
        "shared_name" : "05 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1822,
        "Column_4" : 50,
        "BEND_MAP_ID" : 1822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1820",
        "source" : "520",
        "target" : "504",
        "shared_name" : "05 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1820,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1818",
        "source" : "520",
        "target" : "502",
        "shared_name" : "05 (interacts with) Bg fugo",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Bg fugo",
        "interaction" : "interacts with",
        "SUID" : 1818,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1816",
        "source" : "520",
        "target" : "500",
        "shared_name" : "05 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1816,
        "Column_4" : 44,
        "BEND_MAP_ID" : 1816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1814",
        "source" : "520",
        "target" : "498",
        "shared_name" : "05 (interacts with) Guy bg",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Guy bg",
        "interaction" : "interacts with",
        "SUID" : 1814,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1812",
        "source" : "520",
        "target" : "496",
        "shared_name" : "05 (interacts with) Menini",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Menini",
        "interaction" : "interacts with",
        "SUID" : 1812,
        "Column_4" : 11,
        "BEND_MAP_ID" : 1812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1810",
        "source" : "520",
        "target" : "494",
        "shared_name" : "05 (interacts with) Msita",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Msita",
        "interaction" : "interacts with",
        "SUID" : 1810,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1810,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1808",
        "source" : "520",
        "target" : "590",
        "shared_name" : "05 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1808,
        "Column_4" : 40,
        "BEND_MAP_ID" : 1808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1806",
        "source" : "520",
        "target" : "560",
        "shared_name" : "05 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1806,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1804",
        "source" : "520",
        "target" : "492",
        "shared_name" : "05 (interacts with) Scooter",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Scooter",
        "interaction" : "interacts with",
        "SUID" : 1804,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1802",
        "source" : "520",
        "target" : "490",
        "shared_name" : "05 (interacts with) Naran",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Naran",
        "interaction" : "interacts with",
        "SUID" : 1802,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1800",
        "source" : "520",
        "target" : "488",
        "shared_name" : "05 (interacts with) Naraa",
        "shared_interaction" : "interacts with",
        "name" : "05 (interacts with) Naraa",
        "interaction" : "interacts with",
        "SUID" : 1800,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1798",
        "source" : "486",
        "target" : "500",
        "shared_name" : "06 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1798,
        "Column_4" : 88,
        "BEND_MAP_ID" : 1798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1796",
        "source" : "486",
        "target" : "606",
        "shared_name" : "06 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1796,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1794",
        "source" : "486",
        "target" : "580",
        "shared_name" : "06 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1794,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1792",
        "source" : "486",
        "target" : "484",
        "shared_name" : "06 (interacts with) Isacco",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Isacco",
        "interaction" : "interacts with",
        "SUID" : 1792,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1790",
        "source" : "486",
        "target" : "482",
        "shared_name" : "06 (interacts with) Pimp",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Pimp",
        "interaction" : "interacts with",
        "SUID" : 1790,
        "Column_4" : 21,
        "BEND_MAP_ID" : 1790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1788",
        "source" : "486",
        "target" : "604",
        "shared_name" : "06 (interacts with) Girl",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Girl",
        "interaction" : "interacts with",
        "SUID" : 1788,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1786",
        "source" : "486",
        "target" : "576",
        "shared_name" : "06 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1786,
        "Column_4" : 125,
        "BEND_MAP_ID" : 1786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1784",
        "source" : "486",
        "target" : "480",
        "shared_name" : "06 (interacts with) Sfx",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Sfx",
        "interaction" : "interacts with",
        "SUID" : 1784,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1782",
        "source" : "486",
        "target" : "512",
        "shared_name" : "06 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1782,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1780",
        "source" : "486",
        "target" : "478",
        "shared_name" : "06 (interacts with) Bruno bg",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Bruno bg",
        "interaction" : "interacts with",
        "SUID" : 1780,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1778",
        "source" : "486",
        "target" : "504",
        "shared_name" : "06 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1778,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1776",
        "source" : "486",
        "target" : "476",
        "shared_name" : "06 (interacts with) Sign top",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Sign top",
        "interaction" : "interacts with",
        "SUID" : 1776,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1774",
        "source" : "486",
        "target" : "474",
        "shared_name" : "06 (interacts with) Sign bot",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Sign bot",
        "interaction" : "interacts with",
        "SUID" : 1774,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1772",
        "source" : "486",
        "target" : "472",
        "shared_name" : "06 (interacts with) Bzzzzzz,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Bzzzzzz,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1772,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1770",
        "source" : "486",
        "target" : "516",
        "shared_name" : "06 (interacts with) Mario",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Mario",
        "interaction" : "interacts with",
        "SUID" : 1770,
        "Column_4" : 34,
        "BEND_MAP_ID" : 1770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1768",
        "source" : "486",
        "target" : "470",
        "shared_name" : "06 (interacts with) Baaaaaa,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Baaaaaa,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1768,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1766",
        "source" : "486",
        "target" : "468",
        "shared_name" : "06 (interacts with) Fwip,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Fwip,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1766,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1764",
        "source" : "486",
        "target" : "466",
        "shared_name" : "06 (interacts with) Pop,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "06 (interacts with) Pop,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1764,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1762",
        "source" : "464",
        "target" : "462",
        "shared_name" : "07 (interacts with) Naranr",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Naranr",
        "interaction" : "interacts with",
        "SUID" : 1762,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1760",
        "source" : "464",
        "target" : "490",
        "shared_name" : "07 (interacts with) Naran",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Naran",
        "interaction" : "interacts with",
        "SUID" : 1760,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1758",
        "source" : "464",
        "target" : "508",
        "shared_name" : "07 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1758,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1756",
        "source" : "464",
        "target" : "500",
        "shared_name" : "07 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1756,
        "Column_4" : 14,
        "BEND_MAP_ID" : 1756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1754",
        "source" : "464",
        "target" : "460",
        "shared_name" : "07 (interacts with) Mist",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Mist",
        "interaction" : "interacts with",
        "SUID" : 1754,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1752",
        "source" : "464",
        "target" : "576",
        "shared_name" : "07 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1752,
        "Column_4" : 13,
        "BEND_MAP_ID" : 1752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1750",
        "source" : "464",
        "target" : "506",
        "shared_name" : "07 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1750,
        "Column_4" : 108,
        "BEND_MAP_ID" : 1750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1748",
        "source" : "464",
        "target" : "512",
        "shared_name" : "07 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1748,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1746",
        "source" : "464",
        "target" : "516",
        "shared_name" : "07 (interacts with) Mario",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Mario",
        "interaction" : "interacts with",
        "SUID" : 1746,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1744",
        "source" : "464",
        "target" : "518",
        "shared_name" : "07 (interacts with) Sale",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Sale",
        "interaction" : "interacts with",
        "SUID" : 1744,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1742",
        "source" : "464",
        "target" : "580",
        "shared_name" : "07 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1742,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1740",
        "source" : "464",
        "target" : "458",
        "shared_name" : "07 (interacts with) B*llet",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) B*llet",
        "interaction" : "interacts with",
        "SUID" : 1740,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1738",
        "source" : "464",
        "target" : "456",
        "shared_name" : "07 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 1738,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1736",
        "source" : "464",
        "target" : "606",
        "shared_name" : "07 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1736,
        "Column_4" : 14,
        "BEND_MAP_ID" : 1736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1734",
        "source" : "464",
        "target" : "454",
        "shared_name" : "07 (interacts with) Menace,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Menace,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1734,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1732",
        "source" : "464",
        "target" : "452",
        "shared_name" : "07 (interacts with) Bazoo,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "07 (interacts with) Bazoo,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1732,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1730",
        "source" : "450",
        "target" : "506",
        "shared_name" : "08 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1730,
        "Column_4" : 95,
        "BEND_MAP_ID" : 1730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1728",
        "source" : "450",
        "target" : "448",
        "shared_name" : "08 (interacts with) Six",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Six",
        "interaction" : "interacts with",
        "SUID" : 1728,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1726",
        "source" : "450",
        "target" : "452",
        "shared_name" : "08 (interacts with) Bazoo,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Bazoo,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1726,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1724",
        "source" : "450",
        "target" : "604",
        "shared_name" : "08 (interacts with) Girl",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Girl",
        "interaction" : "interacts with",
        "SUID" : 1724,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1722",
        "source" : "450",
        "target" : "560",
        "shared_name" : "08 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1722,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1720",
        "source" : "450",
        "target" : "446",
        "shared_name" : "08 (interacts with) Thug",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Thug",
        "interaction" : "interacts with",
        "SUID" : 1720,
        "Column_4" : 11,
        "BEND_MAP_ID" : 1720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1718",
        "source" : "450",
        "target" : "518",
        "shared_name" : "08 (interacts with) Sale",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Sale",
        "interaction" : "interacts with",
        "SUID" : 1718,
        "Column_4" : 85,
        "BEND_MAP_ID" : 1718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1716",
        "source" : "450",
        "target" : "606",
        "shared_name" : "08 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1716,
        "Column_4" : 15,
        "BEND_MAP_ID" : 1716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1714",
        "source" : "450",
        "target" : "456",
        "shared_name" : "08 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 1714,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1712",
        "source" : "450",
        "target" : "476",
        "shared_name" : "08 (interacts with) Sign top",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Sign top",
        "interaction" : "interacts with",
        "SUID" : 1712,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1710",
        "source" : "450",
        "target" : "474",
        "shared_name" : "08 (interacts with) Sign bot",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Sign bot",
        "interaction" : "interacts with",
        "SUID" : 1710,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1708",
        "source" : "450",
        "target" : "590",
        "shared_name" : "08 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1708,
        "Column_4" : 10,
        "BEND_MAP_ID" : 1708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1706",
        "source" : "450",
        "target" : "444",
        "shared_name" : "08 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 1706,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1704",
        "source" : "450",
        "target" : "458",
        "shared_name" : "08 (interacts with) B*llet",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) B*llet",
        "interaction" : "interacts with",
        "SUID" : 1704,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1702",
        "source" : "450",
        "target" : "442",
        "shared_name" : "08 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 1702,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1700",
        "source" : "450",
        "target" : "524",
        "shared_name" : "08 (interacts with) Bam,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Bam,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1700,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1698",
        "source" : "450",
        "target" : "440",
        "shared_name" : "08 (interacts with) Seven",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) Seven",
        "interaction" : "interacts with",
        "SUID" : 1698,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1696",
        "source" : "450",
        "target" : "438",
        "shared_name" : "08 (interacts with) All",
        "shared_interaction" : "interacts with",
        "name" : "08 (interacts with) All",
        "interaction" : "interacts with",
        "SUID" : 1696,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1694",
        "source" : "436",
        "target" : "506",
        "shared_name" : "09 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1694,
        "Column_4" : 15,
        "BEND_MAP_ID" : 1694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1692",
        "source" : "436",
        "target" : "508",
        "shared_name" : "09 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1692,
        "Column_4" : 34,
        "BEND_MAP_ID" : 1692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1690",
        "source" : "436",
        "target" : "512",
        "shared_name" : "09 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1690,
        "Column_4" : 91,
        "BEND_MAP_ID" : 1690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1688",
        "source" : "436",
        "target" : "576",
        "shared_name" : "09 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1688,
        "Column_4" : 24,
        "BEND_MAP_ID" : 1688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1686",
        "source" : "436",
        "target" : "500",
        "shared_name" : "09 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1686,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1684",
        "source" : "436",
        "target" : "434",
        "shared_name" : "09 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1684,
        "Column_4" : 17,
        "BEND_MAP_ID" : 1684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1682",
        "source" : "436",
        "target" : "432",
        "shared_name" : "09 (interacts with) Crack,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Crack,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1682,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1680",
        "source" : "436",
        "target" : "430",
        "shared_name" : "09 (interacts with) Peri",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Peri",
        "interaction" : "interacts with",
        "SUID" : 1680,
        "Column_4" : 74,
        "BEND_MAP_ID" : 1680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1678",
        "source" : "436",
        "target" : "428",
        "shared_name" : "09 (interacts with) Prei",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Prei",
        "interaction" : "interacts with",
        "SUID" : 1678,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1676",
        "source" : "436",
        "target" : "426",
        "shared_name" : "09 (interacts with) Plop,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Plop,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1676,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1674",
        "source" : "436",
        "target" : "424",
        "shared_name" : "09 (interacts with) MistA",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) MistA",
        "interaction" : "interacts with",
        "SUID" : 1674,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1672",
        "source" : "436",
        "target" : "422",
        "shared_name" : "09 (interacts with) Form",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Form",
        "interaction" : "interacts with",
        "SUID" : 1672,
        "Column_4" : 77,
        "BEND_MAP_ID" : 1672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1670",
        "source" : "436",
        "target" : "580",
        "shared_name" : "09 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1670,
        "Column_4" : 31,
        "BEND_MAP_ID" : 1670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1668",
        "source" : "436",
        "target" : "420",
        "shared_name" : "09 (interacts with) Find_them,Sign",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Find_them,Sign",
        "interaction" : "interacts with",
        "SUID" : 1668,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1666",
        "source" : "436",
        "target" : "480",
        "shared_name" : "09 (interacts with) Sfx",
        "shared_interaction" : "interacts with",
        "name" : "09 (interacts with) Sfx",
        "interaction" : "interacts with",
        "SUID" : 1666,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1664",
        "source" : "418",
        "target" : "422",
        "shared_name" : "10 (interacts with) Form",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Form",
        "interaction" : "interacts with",
        "SUID" : 1664,
        "Column_4" : 103,
        "BEND_MAP_ID" : 1664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1662",
        "source" : "418",
        "target" : "512",
        "shared_name" : "10 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1662,
        "Column_4" : 62,
        "BEND_MAP_ID" : 1662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1660",
        "source" : "418",
        "target" : "606",
        "shared_name" : "10 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1660,
        "Column_4" : 12,
        "BEND_MAP_ID" : 1660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1658",
        "source" : "418",
        "target" : "434",
        "shared_name" : "10 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1658,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1656",
        "source" : "418",
        "target" : "506",
        "shared_name" : "10 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1656,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1654",
        "source" : "418",
        "target" : "456",
        "shared_name" : "10 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 1654,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1652",
        "source" : "418",
        "target" : "508",
        "shared_name" : "10 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1652,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1650",
        "source" : "418",
        "target" : "500",
        "shared_name" : "10 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1650,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1648",
        "source" : "418",
        "target" : "416",
        "shared_name" : "10 (interacts with) Narancia_s_Heigh,Sign",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Narancia_s_Heigh,Sign",
        "interaction" : "interacts with",
        "SUID" : 1648,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1646",
        "source" : "418",
        "target" : "560",
        "shared_name" : "10 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1646,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1644",
        "source" : "418",
        "target" : "414",
        "shared_name" : "10 (interacts with) Formaggio",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Formaggio",
        "interaction" : "interacts with",
        "SUID" : 1644,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1642",
        "source" : "418",
        "target" : "412",
        "shared_name" : "10 (interacts with) Pesci",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Pesci",
        "interaction" : "interacts with",
        "SUID" : 1642,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1640",
        "source" : "418",
        "target" : "410",
        "shared_name" : "10 (interacts with) Prosciutto",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Prosciutto",
        "interaction" : "interacts with",
        "SUID" : 1640,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1638",
        "source" : "418",
        "target" : "408",
        "shared_name" : "10 (interacts with) Pros",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Pros",
        "interaction" : "interacts with",
        "SUID" : 1638,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1636",
        "source" : "418",
        "target" : "580",
        "shared_name" : "10 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1636,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1634",
        "source" : "418",
        "target" : "406",
        "shared_name" : "10 (interacts with) Risotto",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Risotto",
        "interaction" : "interacts with",
        "SUID" : 1634,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1632",
        "source" : "418",
        "target" : "404",
        "shared_name" : "10 (interacts with) Illuso",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Illuso",
        "interaction" : "interacts with",
        "SUID" : 1632,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1630",
        "source" : "418",
        "target" : "402",
        "shared_name" : "10 (interacts with) Ghiaccio",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Ghiaccio",
        "interaction" : "interacts with",
        "SUID" : 1630,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1628",
        "source" : "418",
        "target" : "400",
        "shared_name" : "10 (interacts with) Melone",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Melone",
        "interaction" : "interacts with",
        "SUID" : 1628,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1626",
        "source" : "418",
        "target" : "398",
        "shared_name" : "10 (interacts with) Ghiacchio",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Ghiacchio",
        "interaction" : "interacts with",
        "SUID" : 1626,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1624",
        "source" : "418",
        "target" : "396",
        "shared_name" : "10 (interacts with) Ghia",
        "shared_interaction" : "interacts with",
        "name" : "10 (interacts with) Ghia",
        "interaction" : "interacts with",
        "SUID" : 1624,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1622",
        "source" : "394",
        "target" : "512",
        "shared_name" : "11 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1622,
        "Column_4" : 118,
        "BEND_MAP_ID" : 1622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1620",
        "source" : "394",
        "target" : "422",
        "shared_name" : "11 (interacts with) Form",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Form",
        "interaction" : "interacts with",
        "SUID" : 1620,
        "Column_4" : 104,
        "BEND_MAP_ID" : 1620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1618",
        "source" : "394",
        "target" : "572",
        "shared_name" : "11 (interacts with) Mom",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Mom",
        "interaction" : "interacts with",
        "SUID" : 1618,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1616",
        "source" : "394",
        "target" : "606",
        "shared_name" : "11 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1616,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1614",
        "source" : "394",
        "target" : "392",
        "shared_name" : "11 (interacts with) Blonde",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Blonde",
        "interaction" : "interacts with",
        "SUID" : 1614,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1612",
        "source" : "394",
        "target" : "602",
        "shared_name" : "11 (interacts with) Cop",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Cop",
        "interaction" : "interacts with",
        "SUID" : 1612,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1610",
        "source" : "394",
        "target" : "560",
        "shared_name" : "11 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1610,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1608",
        "source" : "394",
        "target" : "534",
        "shared_name" : "11 (interacts with) Old",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Old",
        "interaction" : "interacts with",
        "SUID" : 1608,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1606",
        "source" : "394",
        "target" : "508",
        "shared_name" : "11 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1606,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1604",
        "source" : "394",
        "target" : "576",
        "shared_name" : "11 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1604,
        "Column_4" : 18,
        "BEND_MAP_ID" : 1604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1602",
        "source" : "394",
        "target" : "580",
        "shared_name" : "11 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1602,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1600",
        "source" : "394",
        "target" : "416",
        "shared_name" : "11 (interacts with) Narancia_s_Heigh,Sign",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Narancia_s_Heigh,Sign",
        "interaction" : "interacts with",
        "SUID" : 1600,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1598",
        "source" : "394",
        "target" : "452",
        "shared_name" : "11 (interacts with) Bazoo,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Bazoo,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1598,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1596",
        "source" : "394",
        "target" : "500",
        "shared_name" : "11 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1596,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1594",
        "source" : "394",
        "target" : "506",
        "shared_name" : "11 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "11 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1594,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1592",
        "source" : "390",
        "target" : "576",
        "shared_name" : "12 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "12 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1592,
        "Column_4" : 12,
        "BEND_MAP_ID" : 1592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1590",
        "source" : "390",
        "target" : "508",
        "shared_name" : "12 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "12 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1590,
        "Column_4" : 87,
        "BEND_MAP_ID" : 1590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1588",
        "source" : "390",
        "target" : "500",
        "shared_name" : "12 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "12 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1588,
        "Column_4" : 85,
        "BEND_MAP_ID" : 1588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1586",
        "source" : "390",
        "target" : "388",
        "shared_name" : "12 (interacts with) Illu",
        "shared_interaction" : "interacts with",
        "name" : "12 (interacts with) Illu",
        "interaction" : "interacts with",
        "SUID" : 1586,
        "Column_4" : 43,
        "BEND_MAP_ID" : 1586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1584",
        "source" : "390",
        "target" : "474",
        "shared_name" : "12 (interacts with) Sign bot",
        "shared_interaction" : "interacts with",
        "name" : "12 (interacts with) Sign bot",
        "interaction" : "interacts with",
        "SUID" : 1584,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1582",
        "source" : "390",
        "target" : "476",
        "shared_name" : "12 (interacts with) Sign top",
        "shared_interaction" : "interacts with",
        "name" : "12 (interacts with) Sign top",
        "interaction" : "interacts with",
        "SUID" : 1582,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1580",
        "source" : "390",
        "target" : "596",
        "shared_name" : "12 (interacts with) Creep",
        "shared_interaction" : "interacts with",
        "name" : "12 (interacts with) Creep",
        "interaction" : "interacts with",
        "SUID" : 1580,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1578",
        "source" : "390",
        "target" : "606",
        "shared_name" : "12 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "12 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1578,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1576",
        "source" : "390",
        "target" : "404",
        "shared_name" : "12 (interacts with) Illuso",
        "shared_interaction" : "interacts with",
        "name" : "12 (interacts with) Illuso",
        "interaction" : "interacts with",
        "SUID" : 1576,
        "Column_4" : 11,
        "BEND_MAP_ID" : 1576,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1574",
        "source" : "386",
        "target" : "404",
        "shared_name" : "13 (interacts with) Illuso",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Illuso",
        "interaction" : "interacts with",
        "SUID" : 1574,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1572",
        "source" : "386",
        "target" : "508",
        "shared_name" : "13 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1572,
        "Column_4" : 39,
        "BEND_MAP_ID" : 1572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1570",
        "source" : "386",
        "target" : "388",
        "shared_name" : "13 (interacts with) Illu",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Illu",
        "interaction" : "interacts with",
        "SUID" : 1570,
        "Column_4" : 122,
        "BEND_MAP_ID" : 1570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1568",
        "source" : "386",
        "target" : "500",
        "shared_name" : "13 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1568,
        "Column_4" : 69,
        "BEND_MAP_ID" : 1568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1566",
        "source" : "386",
        "target" : "384",
        "shared_name" : "13 (interacts with) Gior",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Gior",
        "interaction" : "interacts with",
        "SUID" : 1566,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1564",
        "source" : "386",
        "target" : "580",
        "shared_name" : "13 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1564,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1562",
        "source" : "386",
        "target" : "590",
        "shared_name" : "13 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1562,
        "Column_4" : 41,
        "BEND_MAP_ID" : 1562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1560",
        "source" : "386",
        "target" : "554",
        "shared_name" : "13 (interacts with) Rumble,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Rumble,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1560,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1558",
        "source" : "386",
        "target" : "480",
        "shared_name" : "13 (interacts with) Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Sfx",
        "interaction" : "interacts with",
        "SUID" : 1558,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1556",
        "source" : "386",
        "target" : "576",
        "shared_name" : "13 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1556,
        "Column_4" : 54,
        "BEND_MAP_ID" : 1556,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1554",
        "source" : "386",
        "target" : "590",
        "shared_name" : "13 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1554,
        "Column_4" : 57,
        "BEND_MAP_ID" : 1554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1552",
        "source" : "386",
        "target" : "558",
        "shared_name" : "13 (interacts with) Gold",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Gold",
        "interaction" : "interacts with",
        "SUID" : 1552,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1550",
        "source" : "386",
        "target" : "556",
        "shared_name" : "13 (interacts with) Bagyah,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Bagyah,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1550,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1548",
        "source" : "386",
        "target" : "536",
        "shared_name" : "13 (interacts with) Polpo",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Polpo",
        "interaction" : "interacts with",
        "SUID" : 1548,
        "Column_4" : 10,
        "BEND_MAP_ID" : 1548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1546",
        "source" : "386",
        "target" : "532",
        "shared_name" : "13 (interacts with) Black",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Black",
        "interaction" : "interacts with",
        "SUID" : 1546,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1544",
        "source" : "386",
        "target" : "588",
        "shared_name" : "13 (interacts with) Koichi",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Koichi",
        "interaction" : "interacts with",
        "SUID" : 1544,
        "Column_4" : 11,
        "BEND_MAP_ID" : 1544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1542",
        "source" : "386",
        "target" : "524",
        "shared_name" : "13 (interacts with) Bam,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Bam,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1542,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1540",
        "source" : "386",
        "target" : "506",
        "shared_name" : "13 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1540,
        "Column_4" : 28,
        "BEND_MAP_ID" : 1540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1538",
        "source" : "386",
        "target" : "512",
        "shared_name" : "13 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1538,
        "Column_4" : 13,
        "BEND_MAP_ID" : 1538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1536",
        "source" : "386",
        "target" : "508",
        "shared_name" : "13 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1536,
        "Column_4" : 10,
        "BEND_MAP_ID" : 1536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1534",
        "source" : "386",
        "target" : "500",
        "shared_name" : "13 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1534,
        "Column_4" : 38,
        "BEND_MAP_ID" : 1534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1532",
        "source" : "386",
        "target" : "504",
        "shared_name" : "13 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1532,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1530",
        "source" : "386",
        "target" : "516",
        "shared_name" : "13 (interacts with) Mario",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Mario",
        "interaction" : "interacts with",
        "SUID" : 1530,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1528",
        "source" : "386",
        "target" : "470",
        "shared_name" : "13 (interacts with) Baaaaaa,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Baaaaaa,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1528,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1526",
        "source" : "386",
        "target" : "468",
        "shared_name" : "13 (interacts with) Fwip,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Fwip,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1526,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1524",
        "source" : "386",
        "target" : "466",
        "shared_name" : "13 (interacts with) Pop,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Pop,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1524,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1522",
        "source" : "386",
        "target" : "456",
        "shared_name" : "13 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 1522,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1520",
        "source" : "386",
        "target" : "452",
        "shared_name" : "13 (interacts with) Bazoo,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Bazoo,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1520,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1518",
        "source" : "386",
        "target" : "518",
        "shared_name" : "13 (interacts with) Sale",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Sale",
        "interaction" : "interacts with",
        "SUID" : 1518,
        "Column_4" : 22,
        "BEND_MAP_ID" : 1518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1516",
        "source" : "386",
        "target" : "458",
        "shared_name" : "13 (interacts with) B*llet",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) B*llet",
        "interaction" : "interacts with",
        "SUID" : 1516,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1514",
        "source" : "386",
        "target" : "442",
        "shared_name" : "13 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 1514,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1512",
        "source" : "386",
        "target" : "440",
        "shared_name" : "13 (interacts with) Seven",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Seven",
        "interaction" : "interacts with",
        "SUID" : 1512,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1510",
        "source" : "386",
        "target" : "438",
        "shared_name" : "13 (interacts with) All",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) All",
        "interaction" : "interacts with",
        "SUID" : 1510,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1510,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1508",
        "source" : "386",
        "target" : "448",
        "shared_name" : "13 (interacts with) Six",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Six",
        "interaction" : "interacts with",
        "SUID" : 1508,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1506",
        "source" : "386",
        "target" : "444",
        "shared_name" : "13 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 1506,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1504",
        "source" : "386",
        "target" : "426",
        "shared_name" : "13 (interacts with) Plop,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Plop,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1504,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1504,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1502",
        "source" : "386",
        "target" : "430",
        "shared_name" : "13 (interacts with) Peri",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Peri",
        "interaction" : "interacts with",
        "SUID" : 1502,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1500",
        "source" : "386",
        "target" : "422",
        "shared_name" : "13 (interacts with) Form",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Form",
        "interaction" : "interacts with",
        "SUID" : 1500,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1498",
        "source" : "386",
        "target" : "404",
        "shared_name" : "13 (interacts with) Illuso",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Illuso",
        "interaction" : "interacts with",
        "SUID" : 1498,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1496",
        "source" : "386",
        "target" : "388",
        "shared_name" : "13 (interacts with) Illu",
        "shared_interaction" : "interacts with",
        "name" : "13 (interacts with) Illu",
        "interaction" : "interacts with",
        "SUID" : 1496,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1494",
        "source" : "382",
        "target" : "500",
        "shared_name" : "14 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1494,
        "Column_4" : 13,
        "BEND_MAP_ID" : 1494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1492",
        "source" : "382",
        "target" : "512",
        "shared_name" : "14 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1492,
        "Column_4" : 45,
        "BEND_MAP_ID" : 1492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1490",
        "source" : "382",
        "target" : "576",
        "shared_name" : "14 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1490,
        "Column_4" : 54,
        "BEND_MAP_ID" : 1490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1488",
        "source" : "382",
        "target" : "506",
        "shared_name" : "14 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1488,
        "Column_4" : 63,
        "BEND_MAP_ID" : 1488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1486",
        "source" : "382",
        "target" : "508",
        "shared_name" : "14 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1486,
        "Column_4" : 10,
        "BEND_MAP_ID" : 1486,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1484",
        "source" : "382",
        "target" : "416",
        "shared_name" : "14 (interacts with) Narancia_s_Heigh,Sign",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Narancia_s_Heigh,Sign",
        "interaction" : "interacts with",
        "SUID" : 1484,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1482",
        "source" : "382",
        "target" : "380",
        "shared_name" : "14 (interacts with) Pro",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Pro",
        "interaction" : "interacts with",
        "SUID" : 1482,
        "Column_4" : 54,
        "BEND_MAP_ID" : 1482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1480",
        "source" : "382",
        "target" : "412",
        "shared_name" : "14 (interacts with) Pesci",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Pesci",
        "interaction" : "interacts with",
        "SUID" : 1480,
        "Column_4" : 41,
        "BEND_MAP_ID" : 1480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1478",
        "source" : "382",
        "target" : "580",
        "shared_name" : "14 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1478,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1476",
        "source" : "382",
        "target" : "600",
        "shared_name" : "14 (interacts with) Kid",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Kid",
        "interaction" : "interacts with",
        "SUID" : 1476,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1474",
        "source" : "382",
        "target" : "434",
        "shared_name" : "14 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "14 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1474,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1474,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1472",
        "source" : "378",
        "target" : "500",
        "shared_name" : "15 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1472,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1470",
        "source" : "378",
        "target" : "412",
        "shared_name" : "15 (interacts with) Pesci",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Pesci",
        "interaction" : "interacts with",
        "SUID" : 1470,
        "Column_4" : 65,
        "BEND_MAP_ID" : 1470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1468",
        "source" : "378",
        "target" : "380",
        "shared_name" : "15 (interacts with) Pro",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Pro",
        "interaction" : "interacts with",
        "SUID" : 1468,
        "Column_4" : 99,
        "BEND_MAP_ID" : 1468,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1466",
        "source" : "378",
        "target" : "506",
        "shared_name" : "15 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1466,
        "Column_4" : 37,
        "BEND_MAP_ID" : 1466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1464",
        "source" : "378",
        "target" : "444",
        "shared_name" : "15 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 1464,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1462",
        "source" : "378",
        "target" : "376",
        "shared_name" : "15 (interacts with) Two",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Two",
        "interaction" : "interacts with",
        "SUID" : 1462,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1460",
        "source" : "378",
        "target" : "440",
        "shared_name" : "15 (interacts with) Seven",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Seven",
        "interaction" : "interacts with",
        "SUID" : 1460,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1458",
        "source" : "378",
        "target" : "448",
        "shared_name" : "15 (interacts with) Six",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Six",
        "interaction" : "interacts with",
        "SUID" : 1458,
        "Column_4" : 10,
        "BEND_MAP_ID" : 1458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1456",
        "source" : "378",
        "target" : "442",
        "shared_name" : "15 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 1456,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1454",
        "source" : "378",
        "target" : "534",
        "shared_name" : "15 (interacts with) Old",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Old",
        "interaction" : "interacts with",
        "SUID" : 1454,
        "Column_4" : 14,
        "BEND_MAP_ID" : 1454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1452",
        "source" : "378",
        "target" : "374",
        "shared_name" : "15 (interacts with) Three",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Three",
        "interaction" : "interacts with",
        "SUID" : 1452,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1450",
        "source" : "378",
        "target" : "580",
        "shared_name" : "15 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1450,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1448",
        "source" : "378",
        "target" : "576",
        "shared_name" : "15 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1448,
        "Column_4" : 27,
        "BEND_MAP_ID" : 1448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1446",
        "source" : "378",
        "target" : "434",
        "shared_name" : "15 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1446,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1444",
        "source" : "378",
        "target" : "372",
        "shared_name" : "15 (interacts with) Misa",
        "shared_interaction" : "interacts with",
        "name" : "15 (interacts with) Misa",
        "interaction" : "interacts with",
        "SUID" : 1444,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1442",
        "source" : "370",
        "target" : "380",
        "shared_name" : "16 (interacts with) Pro",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Pro",
        "interaction" : "interacts with",
        "SUID" : 1442,
        "Column_4" : 32,
        "BEND_MAP_ID" : 1442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1440",
        "source" : "370",
        "target" : "412",
        "shared_name" : "16 (interacts with) Pesci",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Pesci",
        "interaction" : "interacts with",
        "SUID" : 1440,
        "Column_4" : 121,
        "BEND_MAP_ID" : 1440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1438",
        "source" : "370",
        "target" : "576",
        "shared_name" : "16 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1438,
        "Column_4" : 56,
        "BEND_MAP_ID" : 1438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1436",
        "source" : "370",
        "target" : "448",
        "shared_name" : "16 (interacts with) Six",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Six",
        "interaction" : "interacts with",
        "SUID" : 1436,
        "Column_4" : 44,
        "BEND_MAP_ID" : 1436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1434",
        "source" : "370",
        "target" : "606",
        "shared_name" : "16 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1434,
        "Column_4" : 17,
        "BEND_MAP_ID" : 1434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1432",
        "source" : "370",
        "target" : "580",
        "shared_name" : "16 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1432,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1430",
        "source" : "370",
        "target" : "368",
        "shared_name" : "16 (interacts with) Borgh,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Borgh,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1430,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1428",
        "source" : "370",
        "target" : "434",
        "shared_name" : "16 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1428,
        "Column_4" : 10,
        "BEND_MAP_ID" : 1428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1426",
        "source" : "370",
        "target" : "366",
        "shared_name" : "16 (interacts with) Goodbye_,Sign",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Goodbye_,Sign",
        "interaction" : "interacts with",
        "SUID" : 1426,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1424",
        "source" : "370",
        "target" : "364",
        "shared_name" : "16 (interacts with) Prosciutto____De,Sign",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Prosciutto____De,Sign",
        "interaction" : "interacts with",
        "SUID" : 1424,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1422",
        "source" : "370",
        "target" : "362",
        "shared_name" : "16 (interacts with) Phone",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Phone",
        "interaction" : "interacts with",
        "SUID" : 1422,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1420",
        "source" : "370",
        "target" : "400",
        "shared_name" : "16 (interacts with) Melone",
        "shared_interaction" : "interacts with",
        "name" : "16 (interacts with) Melone",
        "interaction" : "interacts with",
        "SUID" : 1420,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1418",
        "source" : "360",
        "target" : "362",
        "shared_name" : "17 (interacts with) Phone",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Phone",
        "interaction" : "interacts with",
        "SUID" : 1418,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1416",
        "source" : "360",
        "target" : "400",
        "shared_name" : "17 (interacts with) Melone",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Melone",
        "interaction" : "interacts with",
        "SUID" : 1416,
        "Column_4" : 105,
        "BEND_MAP_ID" : 1416,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1414",
        "source" : "360",
        "target" : "606",
        "shared_name" : "17 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1414,
        "Column_4" : 12,
        "BEND_MAP_ID" : 1414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1412",
        "source" : "360",
        "target" : "358",
        "shared_name" : "17 (interacts with) Anita",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Anita",
        "interaction" : "interacts with",
        "SUID" : 1412,
        "Column_4" : 37,
        "BEND_MAP_ID" : 1412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1410",
        "source" : "360",
        "target" : "356",
        "shared_name" : "17 (interacts with) Smack,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Smack,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1410,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1408",
        "source" : "360",
        "target" : "580",
        "shared_name" : "17 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1408,
        "Column_4" : 25,
        "BEND_MAP_ID" : 1408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1406",
        "source" : "360",
        "target" : "500",
        "shared_name" : "17 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1406,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1404",
        "source" : "360",
        "target" : "512",
        "shared_name" : "17 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1404,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1402",
        "source" : "360",
        "target" : "442",
        "shared_name" : "17 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 1402,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1400",
        "source" : "360",
        "target" : "506",
        "shared_name" : "17 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1400,
        "Column_4" : 12,
        "BEND_MAP_ID" : 1400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1398",
        "source" : "360",
        "target" : "448",
        "shared_name" : "17 (interacts with) Six",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Six",
        "interaction" : "interacts with",
        "SUID" : 1398,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1396",
        "source" : "360",
        "target" : "374",
        "shared_name" : "17 (interacts with) Three",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Three",
        "interaction" : "interacts with",
        "SUID" : 1396,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1394",
        "source" : "360",
        "target" : "576",
        "shared_name" : "17 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1394,
        "Column_4" : 20,
        "BEND_MAP_ID" : 1394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1392",
        "source" : "360",
        "target" : "508",
        "shared_name" : "17 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1392,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1390",
        "source" : "360",
        "target" : "354",
        "shared_name" : "17 (interacts with) Baby",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Baby",
        "interaction" : "interacts with",
        "SUID" : 1390,
        "Column_4" : 30,
        "BEND_MAP_ID" : 1390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1388",
        "source" : "360",
        "target" : "434",
        "shared_name" : "17 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "17 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1388,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1386",
        "source" : "352",
        "target" : "402",
        "shared_name" : "18 (interacts with) Ghiaccio",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Ghiaccio",
        "interaction" : "interacts with",
        "SUID" : 1386,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1384",
        "source" : "352",
        "target" : "406",
        "shared_name" : "18 (interacts with) Risotto",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Risotto",
        "interaction" : "interacts with",
        "SUID" : 1384,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1382",
        "source" : "352",
        "target" : "396",
        "shared_name" : "18 (interacts with) Ghia",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Ghia",
        "interaction" : "interacts with",
        "SUID" : 1382,
        "Column_4" : 53,
        "BEND_MAP_ID" : 1382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1380",
        "source" : "352",
        "target" : "350",
        "shared_name" : "18 (interacts with) Riso",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Riso",
        "interaction" : "interacts with",
        "SUID" : 1380,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1378",
        "source" : "352",
        "target" : "606",
        "shared_name" : "18 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1378,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1376",
        "source" : "352",
        "target" : "354",
        "shared_name" : "18 (interacts with) Baby",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Baby",
        "interaction" : "interacts with",
        "SUID" : 1376,
        "Column_4" : 20,
        "BEND_MAP_ID" : 1376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1374",
        "source" : "352",
        "target" : "400",
        "shared_name" : "18 (interacts with) Melone",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Melone",
        "interaction" : "interacts with",
        "SUID" : 1374,
        "Column_4" : 24,
        "BEND_MAP_ID" : 1374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1372",
        "source" : "352",
        "target" : "580",
        "shared_name" : "18 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1372,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1370",
        "source" : "352",
        "target" : "348",
        "shared_name" : "18 (interacts with) GW",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) GW",
        "interaction" : "interacts with",
        "SUID" : 1370,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1368",
        "source" : "352",
        "target" : "346",
        "shared_name" : "18 (interacts with) Crush,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Crush,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1368,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1366",
        "source" : "352",
        "target" : "576",
        "shared_name" : "18 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1366,
        "Column_4" : 13,
        "BEND_MAP_ID" : 1366,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1364",
        "source" : "352",
        "target" : "534",
        "shared_name" : "18 (interacts with) Old",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Old",
        "interaction" : "interacts with",
        "SUID" : 1364,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1362",
        "source" : "352",
        "target" : "560",
        "shared_name" : "18 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1362,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1360",
        "source" : "352",
        "target" : "508",
        "shared_name" : "18 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1360,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1358",
        "source" : "352",
        "target" : "506",
        "shared_name" : "18 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1358,
        "Column_4" : 55,
        "BEND_MAP_ID" : 1358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1356",
        "source" : "352",
        "target" : "500",
        "shared_name" : "18 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1356,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1354",
        "source" : "352",
        "target" : "512",
        "shared_name" : "18 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1354,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1352",
        "source" : "352",
        "target" : "430",
        "shared_name" : "18 (interacts with) Peri",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Peri",
        "interaction" : "interacts with",
        "SUID" : 1352,
        "Column_4" : 14,
        "BEND_MAP_ID" : 1352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1350",
        "source" : "352",
        "target" : "344",
        "shared_name" : "18 (interacts with) Dia",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Dia",
        "interaction" : "interacts with",
        "SUID" : 1350,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1350,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1348",
        "source" : "352",
        "target" : "456",
        "shared_name" : "18 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 1348,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1346",
        "source" : "352",
        "target" : "444",
        "shared_name" : "18 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 1346,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1344",
        "source" : "352",
        "target" : "376",
        "shared_name" : "18 (interacts with) Two",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Two",
        "interaction" : "interacts with",
        "SUID" : 1344,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1342",
        "source" : "352",
        "target" : "374",
        "shared_name" : "18 (interacts with) Three",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Three",
        "interaction" : "interacts with",
        "SUID" : 1342,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1340",
        "source" : "352",
        "target" : "438",
        "shared_name" : "18 (interacts with) All",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) All",
        "interaction" : "interacts with",
        "SUID" : 1340,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1338",
        "source" : "342",
        "target" : "590",
        "shared_name" : "19 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1338,
        "Column_4" : 59,
        "BEND_MAP_ID" : 1338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1336",
        "source" : "342",
        "target" : "506",
        "shared_name" : "19 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1336,
        "Column_4" : 96,
        "BEND_MAP_ID" : 1336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1334",
        "source" : "342",
        "target" : "396",
        "shared_name" : "19 (interacts with) Ghia",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Ghia",
        "interaction" : "interacts with",
        "SUID" : 1334,
        "Column_4" : 76,
        "BEND_MAP_ID" : 1334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1332",
        "source" : "342",
        "target" : "424",
        "shared_name" : "19 (interacts with) MistA",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) MistA",
        "interaction" : "interacts with",
        "SUID" : 1332,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1330",
        "source" : "342",
        "target" : "504",
        "shared_name" : "19 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1330,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1328",
        "source" : "342",
        "target" : "442",
        "shared_name" : "19 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 1328,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1326",
        "source" : "342",
        "target" : "448",
        "shared_name" : "19 (interacts with) Six",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Six",
        "interaction" : "interacts with",
        "SUID" : 1326,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1324",
        "source" : "342",
        "target" : "440",
        "shared_name" : "19 (interacts with) Seven",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Seven",
        "interaction" : "interacts with",
        "SUID" : 1324,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1322",
        "source" : "342",
        "target" : "374",
        "shared_name" : "19 (interacts with) Three",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Three",
        "interaction" : "interacts with",
        "SUID" : 1322,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1320",
        "source" : "342",
        "target" : "444",
        "shared_name" : "19 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 1320,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1318",
        "source" : "342",
        "target" : "376",
        "shared_name" : "19 (interacts with) Two",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Two",
        "interaction" : "interacts with",
        "SUID" : 1318,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1316",
        "source" : "342",
        "target" : "340",
        "shared_name" : "19 (interacts with) Both",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Both",
        "interaction" : "interacts with",
        "SUID" : 1316,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1314",
        "source" : "342",
        "target" : "580",
        "shared_name" : "19 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1314,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1312",
        "source" : "342",
        "target" : "338",
        "shared_name" : "19 (interacts with) Guard",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Guard",
        "interaction" : "interacts with",
        "SUID" : 1312,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1310",
        "source" : "342",
        "target" : "576",
        "shared_name" : "19 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1310,
        "Column_4" : 17,
        "BEND_MAP_ID" : 1310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1308",
        "source" : "342",
        "target" : "606",
        "shared_name" : "19 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1308,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1306",
        "source" : "342",
        "target" : "456",
        "shared_name" : "19 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 1306,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1304",
        "source" : "342",
        "target" : "480",
        "shared_name" : "19 (interacts with) Sfx",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Sfx",
        "interaction" : "interacts with",
        "SUID" : 1304,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1302",
        "source" : "342",
        "target" : "558",
        "shared_name" : "19 (interacts with) Gold",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Gold",
        "interaction" : "interacts with",
        "SUID" : 1302,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1300",
        "source" : "342",
        "target" : "512",
        "shared_name" : "19 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1300,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1298",
        "source" : "342",
        "target" : "336",
        "shared_name" : "19 (interacts with) Risotto_s_wherea,Sign",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Risotto_s_wherea,Sign",
        "interaction" : "interacts with",
        "SUID" : 1298,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1296",
        "source" : "342",
        "target" : "334",
        "shared_name" : "19 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "19 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 1296,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1294",
        "source" : "332",
        "target" : "576",
        "shared_name" : "20 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1294,
        "Column_4" : 138,
        "BEND_MAP_ID" : 1294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1292",
        "source" : "332",
        "target" : "508",
        "shared_name" : "20 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1292,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1290",
        "source" : "332",
        "target" : "580",
        "shared_name" : "20 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1290,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1288",
        "source" : "332",
        "target" : "590",
        "shared_name" : "20 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1288,
        "Column_4" : 11,
        "BEND_MAP_ID" : 1288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1286",
        "source" : "332",
        "target" : "512",
        "shared_name" : "20 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1286,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1284",
        "source" : "332",
        "target" : "500",
        "shared_name" : "20 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1284,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1282",
        "source" : "332",
        "target" : "506",
        "shared_name" : "20 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1282,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1280",
        "source" : "332",
        "target" : "434",
        "shared_name" : "20 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1280,
        "Column_4" : 12,
        "BEND_MAP_ID" : 1280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1278",
        "source" : "332",
        "target" : "568",
        "shared_name" : "20 (interacts with) Dad",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Dad",
        "interaction" : "interacts with",
        "SUID" : 1278,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1276",
        "source" : "332",
        "target" : "572",
        "shared_name" : "20 (interacts with) Mom",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Mom",
        "interaction" : "interacts with",
        "SUID" : 1276,
        "Column_4" : 17,
        "BEND_MAP_ID" : 1276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1274",
        "source" : "332",
        "target" : "606",
        "shared_name" : "20 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1274,
        "Column_4" : 15,
        "BEND_MAP_ID" : 1274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1272",
        "source" : "332",
        "target" : "330",
        "shared_name" : "20 (interacts with) Nurse",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Nurse",
        "interaction" : "interacts with",
        "SUID" : 1272,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1270",
        "source" : "332",
        "target" : "560",
        "shared_name" : "20 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1270,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1268",
        "source" : "332",
        "target" : "602",
        "shared_name" : "20 (interacts with) Cop",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Cop",
        "interaction" : "interacts with",
        "SUID" : 1268,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1266",
        "source" : "332",
        "target" : "542",
        "shared_name" : "20 (interacts with) Thud,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Thud,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1266,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1264",
        "source" : "332",
        "target" : "328",
        "shared_name" : "20 (interacts with) Punk",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Punk",
        "interaction" : "interacts with",
        "SUID" : 1264,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1262",
        "source" : "332",
        "target" : "334",
        "shared_name" : "20 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "20 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 1262,
        "Column_4" : 22,
        "BEND_MAP_ID" : 1262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1260",
        "source" : "326",
        "target" : "506",
        "shared_name" : "21 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1260,
        "Column_4" : 20,
        "BEND_MAP_ID" : 1260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1258",
        "source" : "326",
        "target" : "512",
        "shared_name" : "21 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1258,
        "Column_4" : 32,
        "BEND_MAP_ID" : 1258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1256",
        "source" : "326",
        "target" : "508",
        "shared_name" : "21 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1256,
        "Column_4" : 40,
        "BEND_MAP_ID" : 1256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1254",
        "source" : "326",
        "target" : "500",
        "shared_name" : "21 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1254,
        "Column_4" : 27,
        "BEND_MAP_ID" : 1254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1252",
        "source" : "326",
        "target" : "576",
        "shared_name" : "21 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1252,
        "Column_4" : 106,
        "BEND_MAP_ID" : 1252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1250",
        "source" : "326",
        "target" : "334",
        "shared_name" : "21 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 1250,
        "Column_4" : 62,
        "BEND_MAP_ID" : 1250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1248",
        "source" : "326",
        "target" : "504",
        "shared_name" : "21 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1248,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1246",
        "source" : "326",
        "target" : "324",
        "shared_name" : "21 (interacts with) Burno",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Burno",
        "interaction" : "interacts with",
        "SUID" : 1246,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1244",
        "source" : "326",
        "target" : "580",
        "shared_name" : "21 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1244,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1242",
        "source" : "326",
        "target" : "590",
        "shared_name" : "21 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1242,
        "Column_4" : 50,
        "BEND_MAP_ID" : 1242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1240",
        "source" : "326",
        "target" : "322",
        "shared_name" : "21 (interacts with) Doppio",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Doppio",
        "interaction" : "interacts with",
        "SUID" : 1240,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1238",
        "source" : "326",
        "target" : "576",
        "shared_name" : "21 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1238,
        "Column_4" : 58,
        "BEND_MAP_ID" : 1238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1236",
        "source" : "326",
        "target" : "580",
        "shared_name" : "21 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1236,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1234",
        "source" : "326",
        "target" : "500",
        "shared_name" : "21 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1234,
        "Column_4" : 14,
        "BEND_MAP_ID" : 1234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1232",
        "source" : "326",
        "target" : "482",
        "shared_name" : "21 (interacts with) Pimp",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Pimp",
        "interaction" : "interacts with",
        "SUID" : 1232,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1230",
        "source" : "326",
        "target" : "606",
        "shared_name" : "21 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1230,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1228",
        "source" : "326",
        "target" : "388",
        "shared_name" : "21 (interacts with) Illu",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Illu",
        "interaction" : "interacts with",
        "SUID" : 1228,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1226",
        "source" : "326",
        "target" : "512",
        "shared_name" : "21 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1226,
        "Column_4" : 17,
        "BEND_MAP_ID" : 1226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1224",
        "source" : "326",
        "target" : "392",
        "shared_name" : "21 (interacts with) Blonde",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Blonde",
        "interaction" : "interacts with",
        "SUID" : 1224,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1222",
        "source" : "326",
        "target" : "602",
        "shared_name" : "21 (interacts with) Cop",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Cop",
        "interaction" : "interacts with",
        "SUID" : 1222,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1220",
        "source" : "326",
        "target" : "508",
        "shared_name" : "21 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 1220,
        "Column_4" : 18,
        "BEND_MAP_ID" : 1220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1218",
        "source" : "326",
        "target" : "596",
        "shared_name" : "21 (interacts with) Creep",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Creep",
        "interaction" : "interacts with",
        "SUID" : 1218,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1216",
        "source" : "326",
        "target" : "446",
        "shared_name" : "21 (interacts with) Thug",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Thug",
        "interaction" : "interacts with",
        "SUID" : 1216,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1214",
        "source" : "326",
        "target" : "506",
        "shared_name" : "21 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1214,
        "Column_4" : 15,
        "BEND_MAP_ID" : 1214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1212",
        "source" : "326",
        "target" : "444",
        "shared_name" : "21 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 1212,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1210",
        "source" : "326",
        "target" : "374",
        "shared_name" : "21 (interacts with) Three",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Three",
        "interaction" : "interacts with",
        "SUID" : 1210,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1208",
        "source" : "326",
        "target" : "376",
        "shared_name" : "21 (interacts with) Two",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Two",
        "interaction" : "interacts with",
        "SUID" : 1208,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1206",
        "source" : "326",
        "target" : "448",
        "shared_name" : "21 (interacts with) Six",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Six",
        "interaction" : "interacts with",
        "SUID" : 1206,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1204",
        "source" : "326",
        "target" : "338",
        "shared_name" : "21 (interacts with) Guard",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Guard",
        "interaction" : "interacts with",
        "SUID" : 1204,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1202",
        "source" : "326",
        "target" : "590",
        "shared_name" : "21 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1202,
        "Column_4" : 30,
        "BEND_MAP_ID" : 1202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1200",
        "source" : "326",
        "target" : "548",
        "shared_name" : "21 (interacts with) Kabaam,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Kabaam,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1200,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1198",
        "source" : "326",
        "target" : "422",
        "shared_name" : "21 (interacts with) Form",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Form",
        "interaction" : "interacts with",
        "SUID" : 1198,
        "Column_4" : 14,
        "BEND_MAP_ID" : 1198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1196",
        "source" : "326",
        "target" : "560",
        "shared_name" : "21 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1196,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1194",
        "source" : "326",
        "target" : "408",
        "shared_name" : "21 (interacts with) Pros",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Pros",
        "interaction" : "interacts with",
        "SUID" : 1194,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1192",
        "source" : "326",
        "target" : "406",
        "shared_name" : "21 (interacts with) Risotto",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Risotto",
        "interaction" : "interacts with",
        "SUID" : 1192,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1190",
        "source" : "326",
        "target" : "402",
        "shared_name" : "21 (interacts with) Ghiaccio",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Ghiaccio",
        "interaction" : "interacts with",
        "SUID" : 1190,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1188",
        "source" : "326",
        "target" : "400",
        "shared_name" : "21 (interacts with) Melone",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Melone",
        "interaction" : "interacts with",
        "SUID" : 1188,
        "Column_4" : 6,
        "BEND_MAP_ID" : 1188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1186",
        "source" : "326",
        "target" : "404",
        "shared_name" : "21 (interacts with) Illuso",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Illuso",
        "interaction" : "interacts with",
        "SUID" : 1186,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1184",
        "source" : "326",
        "target" : "398",
        "shared_name" : "21 (interacts with) Ghiacchio",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Ghiacchio",
        "interaction" : "interacts with",
        "SUID" : 1184,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1182",
        "source" : "326",
        "target" : "514",
        "shared_name" : "21 (interacts with) Rome___a_m_,Sign",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Rome___a_m_,Sign",
        "interaction" : "interacts with",
        "SUID" : 1182,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1180",
        "source" : "326",
        "target" : "396",
        "shared_name" : "21 (interacts with) Ghia",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Ghia",
        "interaction" : "interacts with",
        "SUID" : 1180,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1178",
        "source" : "326",
        "target" : "354",
        "shared_name" : "21 (interacts with) Baby",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Baby",
        "interaction" : "interacts with",
        "SUID" : 1178,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1176",
        "source" : "326",
        "target" : "424",
        "shared_name" : "21 (interacts with) MistA",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) MistA",
        "interaction" : "interacts with",
        "SUID" : 1176,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1174",
        "source" : "326",
        "target" : "434",
        "shared_name" : "21 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1174,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1172",
        "source" : "326",
        "target" : "334",
        "shared_name" : "21 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 1172,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1170",
        "source" : "320",
        "target" : "512",
        "shared_name" : "22 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1170,
        "Column_4" : 81,
        "BEND_MAP_ID" : 1170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1168",
        "source" : "320",
        "target" : "576",
        "shared_name" : "22 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1168,
        "Column_4" : 47,
        "BEND_MAP_ID" : 1168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1166",
        "source" : "320",
        "target" : "500",
        "shared_name" : "22 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1166,
        "Column_4" : 40,
        "BEND_MAP_ID" : 1166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1164",
        "source" : "320",
        "target" : "376",
        "shared_name" : "22 (interacts with) Two",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Two",
        "interaction" : "interacts with",
        "SUID" : 1164,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1162",
        "source" : "320",
        "target" : "458",
        "shared_name" : "22 (interacts with) B*llet",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) B*llet",
        "interaction" : "interacts with",
        "SUID" : 1162,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1160",
        "source" : "320",
        "target" : "374",
        "shared_name" : "22 (interacts with) Three",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Three",
        "interaction" : "interacts with",
        "SUID" : 1160,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1158",
        "source" : "320",
        "target" : "444",
        "shared_name" : "22 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 1158,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1156",
        "source" : "320",
        "target" : "506",
        "shared_name" : "22 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1156,
        "Column_4" : 66,
        "BEND_MAP_ID" : 1156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1154",
        "source" : "320",
        "target" : "606",
        "shared_name" : "22 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1154,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1152",
        "source" : "320",
        "target" : "504",
        "shared_name" : "22 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1152,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1150",
        "source" : "320",
        "target" : "434",
        "shared_name" : "22 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1150,
        "Column_4" : 15,
        "BEND_MAP_ID" : 1150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1148",
        "source" : "320",
        "target" : "318",
        "shared_name" : "22 (interacts with) Squalo",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Squalo",
        "interaction" : "interacts with",
        "SUID" : 1148,
        "Column_4" : 14,
        "BEND_MAP_ID" : 1148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1146",
        "source" : "320",
        "target" : "316",
        "shared_name" : "22 (interacts with) Tiziano",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Tiziano",
        "interaction" : "interacts with",
        "SUID" : 1146,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1144",
        "source" : "320",
        "target" : "580",
        "shared_name" : "22 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1144,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1142",
        "source" : "320",
        "target" : "314",
        "shared_name" : "22 (interacts with) Aba",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Aba",
        "interaction" : "interacts with",
        "SUID" : 1142,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1140",
        "source" : "320",
        "target" : "590",
        "shared_name" : "22 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1140,
        "Column_4" : 44,
        "BEND_MAP_ID" : 1140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1138",
        "source" : "320",
        "target" : "312",
        "shared_name" : "22 (interacts with) Giono",
        "shared_interaction" : "interacts with",
        "name" : "22 (interacts with) Giono",
        "interaction" : "interacts with",
        "SUID" : 1138,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1136",
        "source" : "310",
        "target" : "318",
        "shared_name" : "23 (interacts with) Squalo",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Squalo",
        "interaction" : "interacts with",
        "SUID" : 1136,
        "Column_4" : 81,
        "BEND_MAP_ID" : 1136,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1134",
        "source" : "310",
        "target" : "316",
        "shared_name" : "23 (interacts with) Tiziano",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Tiziano",
        "interaction" : "interacts with",
        "SUID" : 1134,
        "Column_4" : 15,
        "BEND_MAP_ID" : 1134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1132",
        "source" : "310",
        "target" : "512",
        "shared_name" : "23 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1132,
        "Column_4" : 117,
        "BEND_MAP_ID" : 1132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1130",
        "source" : "310",
        "target" : "308",
        "shared_name" : "23 (interacts with) Tizi",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Tizi",
        "interaction" : "interacts with",
        "SUID" : 1130,
        "Column_4" : 71,
        "BEND_MAP_ID" : 1130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1128",
        "source" : "310",
        "target" : "500",
        "shared_name" : "23 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1128,
        "Column_4" : 10,
        "BEND_MAP_ID" : 1128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1126",
        "source" : "310",
        "target" : "576",
        "shared_name" : "23 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1126,
        "Column_4" : 11,
        "BEND_MAP_ID" : 1126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1124",
        "source" : "310",
        "target" : "506",
        "shared_name" : "23 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1124,
        "Column_4" : 8,
        "BEND_MAP_ID" : 1124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1122",
        "source" : "310",
        "target" : "580",
        "shared_name" : "23 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1122,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1120",
        "source" : "310",
        "target" : "306",
        "shared_name" : "23 (interacts with) Rome___a_m_,Nara",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Rome___a_m_,Nara",
        "interaction" : "interacts with",
        "SUID" : 1120,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1118",
        "source" : "310",
        "target" : "606",
        "shared_name" : "23 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1118,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1118,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1116",
        "source" : "310",
        "target" : "590",
        "shared_name" : "23 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 1116,
        "Column_4" : 11,
        "BEND_MAP_ID" : 1116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1114",
        "source" : "304",
        "target" : "576",
        "shared_name" : "24 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1114,
        "Column_4" : 70,
        "BEND_MAP_ID" : 1114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1112",
        "source" : "304",
        "target" : "580",
        "shared_name" : "24 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1112,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1110",
        "source" : "304",
        "target" : "512",
        "shared_name" : "24 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1110,
        "Column_4" : 20,
        "BEND_MAP_ID" : 1110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1108",
        "source" : "304",
        "target" : "500",
        "shared_name" : "24 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1108,
        "Column_4" : 5,
        "BEND_MAP_ID" : 1108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1106",
        "source" : "304",
        "target" : "434",
        "shared_name" : "24 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1106,
        "Column_4" : 49,
        "BEND_MAP_ID" : 1106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1104",
        "source" : "304",
        "target" : "506",
        "shared_name" : "24 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1104,
        "Column_4" : 40,
        "BEND_MAP_ID" : 1104,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1102",
        "source" : "304",
        "target" : "456",
        "shared_name" : "24 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 1102,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1100",
        "source" : "304",
        "target" : "504",
        "shared_name" : "24 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1100,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1098",
        "source" : "304",
        "target" : "302",
        "shared_name" : "24 (interacts with) GIO",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) GIO",
        "interaction" : "interacts with",
        "SUID" : 1098,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1098,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1096",
        "source" : "304",
        "target" : "300",
        "shared_name" : "24 (interacts with) Runo",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) Runo",
        "interaction" : "interacts with",
        "SUID" : 1096,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1096,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1094",
        "source" : "304",
        "target" : "458",
        "shared_name" : "24 (interacts with) B*llet",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) B*llet",
        "interaction" : "interacts with",
        "SUID" : 1094,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1092",
        "source" : "304",
        "target" : "298",
        "shared_name" : "24 (interacts with) Tirsh",
        "shared_interaction" : "interacts with",
        "name" : "24 (interacts with) Tirsh",
        "interaction" : "interacts with",
        "SUID" : 1092,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1092,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1090",
        "source" : "296",
        "target" : "434",
        "shared_name" : "25 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "25 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 1090,
        "Column_4" : 106,
        "BEND_MAP_ID" : 1090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1088",
        "source" : "296",
        "target" : "294",
        "shared_name" : "25 (interacts with) Spice",
        "shared_interaction" : "interacts with",
        "name" : "25 (interacts with) Spice",
        "interaction" : "interacts with",
        "SUID" : 1088,
        "Column_4" : 43,
        "BEND_MAP_ID" : 1088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1086",
        "source" : "296",
        "target" : "580",
        "shared_name" : "25 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "25 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1086,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1086,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1084",
        "source" : "296",
        "target" : "576",
        "shared_name" : "25 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "25 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1084,
        "Column_4" : 33,
        "BEND_MAP_ID" : 1084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1082",
        "source" : "296",
        "target" : "500",
        "shared_name" : "25 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "25 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1082,
        "Column_4" : 23,
        "BEND_MAP_ID" : 1082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1080",
        "source" : "296",
        "target" : "292",
        "shared_name" : "25 (interacts with) Spicy",
        "shared_interaction" : "interacts with",
        "name" : "25 (interacts with) Spicy",
        "interaction" : "interacts with",
        "SUID" : 1080,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1078",
        "source" : "296",
        "target" : "290",
        "shared_name" : "25 (interacts with) Diavolo",
        "shared_interaction" : "interacts with",
        "name" : "25 (interacts with) Diavolo",
        "interaction" : "interacts with",
        "SUID" : 1078,
        "Column_4" : 30,
        "BEND_MAP_ID" : 1078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1076",
        "source" : "296",
        "target" : "560",
        "shared_name" : "25 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "25 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1076,
        "Column_4" : 7,
        "BEND_MAP_ID" : 1076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1074",
        "source" : "288",
        "target" : "580",
        "shared_name" : "26 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1074,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1072",
        "source" : "288",
        "target" : "560",
        "shared_name" : "26 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 1072,
        "Column_4" : 20,
        "BEND_MAP_ID" : 1072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1070",
        "source" : "288",
        "target" : "286",
        "shared_name" : "26 (interacts with) Inmate",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Inmate",
        "interaction" : "interacts with",
        "SUID" : 1070,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1068",
        "source" : "288",
        "target" : "284",
        "shared_name" : "26 (interacts with) Inamate",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Inamate",
        "interaction" : "interacts with",
        "SUID" : 1068,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1066",
        "source" : "288",
        "target" : "322",
        "shared_name" : "26 (interacts with) Doppio",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Doppio",
        "interaction" : "interacts with",
        "SUID" : 1066,
        "Column_4" : 105,
        "BEND_MAP_ID" : 1066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1064",
        "source" : "288",
        "target" : "282",
        "shared_name" : "26 (interacts with) Man",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Man",
        "interaction" : "interacts with",
        "SUID" : 1064,
        "Column_4" : 4,
        "BEND_MAP_ID" : 1064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1062",
        "source" : "288",
        "target" : "604",
        "shared_name" : "26 (interacts with) Girl",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Girl",
        "interaction" : "interacts with",
        "SUID" : 1062,
        "Column_4" : 10,
        "BEND_MAP_ID" : 1062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1060",
        "source" : "288",
        "target" : "280",
        "shared_name" : "26 (interacts with) Priest",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Priest",
        "interaction" : "interacts with",
        "SUID" : 1060,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1060,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1058",
        "source" : "288",
        "target" : "606",
        "shared_name" : "26 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 1058,
        "Column_4" : 45,
        "BEND_MAP_ID" : 1058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1056",
        "source" : "288",
        "target" : "278",
        "shared_name" : "26 (interacts with) Boy",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Boy",
        "interaction" : "interacts with",
        "SUID" : 1056,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1054",
        "source" : "288",
        "target" : "594",
        "shared_name" : "26 (interacts with) Driver",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Driver",
        "interaction" : "interacts with",
        "SUID" : 1054,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1052",
        "source" : "288",
        "target" : "290",
        "shared_name" : "26 (interacts with) Diavolo",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Diavolo",
        "interaction" : "interacts with",
        "SUID" : 1052,
        "Column_4" : 28,
        "BEND_MAP_ID" : 1052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1050",
        "source" : "288",
        "target" : "600",
        "shared_name" : "26 (interacts with) Kid",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Kid",
        "interaction" : "interacts with",
        "SUID" : 1050,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1048",
        "source" : "288",
        "target" : "276",
        "shared_name" : "26 (interacts with) Taxi",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Taxi",
        "interaction" : "interacts with",
        "SUID" : 1048,
        "Column_4" : 13,
        "BEND_MAP_ID" : 1048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1046",
        "source" : "288",
        "target" : "406",
        "shared_name" : "26 (interacts with) Risotto",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Risotto",
        "interaction" : "interacts with",
        "SUID" : 1046,
        "Column_4" : 37,
        "BEND_MAP_ID" : 1046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1044",
        "source" : "288",
        "target" : "334",
        "shared_name" : "26 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "26 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 1044,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1042",
        "source" : "274",
        "target" : "344",
        "shared_name" : "27 (interacts with) Dia",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Dia",
        "interaction" : "interacts with",
        "SUID" : 1042,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1040",
        "source" : "274",
        "target" : "334",
        "shared_name" : "27 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 1040,
        "Column_4" : 74,
        "BEND_MAP_ID" : 1040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1038",
        "source" : "274",
        "target" : "272",
        "shared_name" : "27 (interacts with) Dopp",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Dopp",
        "interaction" : "interacts with",
        "SUID" : 1038,
        "Column_4" : 104,
        "BEND_MAP_ID" : 1038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1036",
        "source" : "274",
        "target" : "350",
        "shared_name" : "27 (interacts with) Riso",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Riso",
        "interaction" : "interacts with",
        "SUID" : 1036,
        "Column_4" : 94,
        "BEND_MAP_ID" : 1036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1034",
        "source" : "274",
        "target" : "504",
        "shared_name" : "27 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1034,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1032",
        "source" : "274",
        "target" : "580",
        "shared_name" : "27 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 1032,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1030",
        "source" : "274",
        "target" : "380",
        "shared_name" : "27 (interacts with) Pro",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Pro",
        "interaction" : "interacts with",
        "SUID" : 1030,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1028",
        "source" : "274",
        "target" : "396",
        "shared_name" : "27 (interacts with) Ghia",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Ghia",
        "interaction" : "interacts with",
        "SUID" : 1028,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1026",
        "source" : "274",
        "target" : "422",
        "shared_name" : "27 (interacts with) Form",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Form",
        "interaction" : "interacts with",
        "SUID" : 1026,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1024",
        "source" : "274",
        "target" : "412",
        "shared_name" : "27 (interacts with) Pesci",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Pesci",
        "interaction" : "interacts with",
        "SUID" : 1024,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1022",
        "source" : "274",
        "target" : "400",
        "shared_name" : "27 (interacts with) Melone",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Melone",
        "interaction" : "interacts with",
        "SUID" : 1022,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1020",
        "source" : "274",
        "target" : "388",
        "shared_name" : "27 (interacts with) Illu",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Illu",
        "interaction" : "interacts with",
        "SUID" : 1020,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1018",
        "source" : "274",
        "target" : "576",
        "shared_name" : "27 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1018,
        "Column_4" : 2,
        "BEND_MAP_ID" : 1018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1016",
        "source" : "274",
        "target" : "512",
        "shared_name" : "27 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "27 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1016,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1014",
        "source" : "270",
        "target" : "334",
        "shared_name" : "28 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 1014,
        "Column_4" : 30,
        "BEND_MAP_ID" : 1014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1012",
        "source" : "270",
        "target" : "350",
        "shared_name" : "28 (interacts with) Riso",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Riso",
        "interaction" : "interacts with",
        "SUID" : 1012,
        "Column_4" : 13,
        "BEND_MAP_ID" : 1012,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1010",
        "source" : "270",
        "target" : "512",
        "shared_name" : "28 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 1010,
        "Column_4" : 68,
        "BEND_MAP_ID" : 1010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1008",
        "source" : "270",
        "target" : "500",
        "shared_name" : "28 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 1008,
        "Column_4" : 42,
        "BEND_MAP_ID" : 1008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1006",
        "source" : "270",
        "target" : "576",
        "shared_name" : "28 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 1006,
        "Column_4" : 71,
        "BEND_MAP_ID" : 1006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1004",
        "source" : "270",
        "target" : "268",
        "shared_name" : "28 (interacts with) Rios",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Rios",
        "interaction" : "interacts with",
        "SUID" : 1004,
        "Column_4" : 1,
        "BEND_MAP_ID" : 1004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1002",
        "source" : "270",
        "target" : "504",
        "shared_name" : "28 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 1002,
        "Column_4" : 3,
        "BEND_MAP_ID" : 1002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1000",
        "source" : "270",
        "target" : "506",
        "shared_name" : "28 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 1000,
        "Column_4" : 9,
        "BEND_MAP_ID" : 1000,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "998",
        "source" : "270",
        "target" : "600",
        "shared_name" : "28 (interacts with) Kid",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Kid",
        "interaction" : "interacts with",
        "SUID" : 998,
        "Column_4" : 29,
        "BEND_MAP_ID" : 998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "996",
        "source" : "270",
        "target" : "266",
        "shared_name" : "28 (interacts with) Dop",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Dop",
        "interaction" : "interacts with",
        "SUID" : 996,
        "Column_4" : 1,
        "BEND_MAP_ID" : 996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "994",
        "source" : "270",
        "target" : "580",
        "shared_name" : "28 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 994,
        "Column_4" : 2,
        "BEND_MAP_ID" : 994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "992",
        "source" : "270",
        "target" : "602",
        "shared_name" : "28 (interacts with) Cop",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Cop",
        "interaction" : "interacts with",
        "SUID" : 992,
        "Column_4" : 39,
        "BEND_MAP_ID" : 992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "990",
        "source" : "270",
        "target" : "264",
        "shared_name" : "28 (interacts with) ",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) ",
        "interaction" : "interacts with",
        "SUID" : 990,
        "Column_4" : 2,
        "BEND_MAP_ID" : 990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "988",
        "source" : "270",
        "target" : "580",
        "shared_name" : "28 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 988,
        "Column_4" : 1,
        "BEND_MAP_ID" : 988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "986",
        "source" : "270",
        "target" : "434",
        "shared_name" : "28 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 986,
        "Column_4" : 48,
        "BEND_MAP_ID" : 986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "984",
        "source" : "270",
        "target" : "422",
        "shared_name" : "28 (interacts with) Form",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Form",
        "interaction" : "interacts with",
        "SUID" : 984,
        "Column_4" : 1,
        "BEND_MAP_ID" : 984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "982",
        "source" : "270",
        "target" : "512",
        "shared_name" : "28 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 982,
        "Column_4" : 17,
        "BEND_MAP_ID" : 982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "980",
        "source" : "270",
        "target" : "388",
        "shared_name" : "28 (interacts with) Illu",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Illu",
        "interaction" : "interacts with",
        "SUID" : 980,
        "Column_4" : 1,
        "BEND_MAP_ID" : 980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "978",
        "source" : "270",
        "target" : "380",
        "shared_name" : "28 (interacts with) Pro",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Pro",
        "interaction" : "interacts with",
        "SUID" : 978,
        "Column_4" : 1,
        "BEND_MAP_ID" : 978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "976",
        "source" : "270",
        "target" : "412",
        "shared_name" : "28 (interacts with) Pesci",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Pesci",
        "interaction" : "interacts with",
        "SUID" : 976,
        "Column_4" : 1,
        "BEND_MAP_ID" : 976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "974",
        "source" : "270",
        "target" : "400",
        "shared_name" : "28 (interacts with) Melone",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Melone",
        "interaction" : "interacts with",
        "SUID" : 974,
        "Column_4" : 2,
        "BEND_MAP_ID" : 974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "972",
        "source" : "270",
        "target" : "396",
        "shared_name" : "28 (interacts with) Ghia",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Ghia",
        "interaction" : "interacts with",
        "SUID" : 972,
        "Column_4" : 1,
        "BEND_MAP_ID" : 972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "970",
        "source" : "270",
        "target" : "262",
        "shared_name" : "28 (interacts with) Setting",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Setting",
        "interaction" : "interacts with",
        "SUID" : 970,
        "Column_4" : 17,
        "BEND_MAP_ID" : 970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "968",
        "source" : "270",
        "target" : "508",
        "shared_name" : "28 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 968,
        "Column_4" : 8,
        "BEND_MAP_ID" : 968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "966",
        "source" : "270",
        "target" : "576",
        "shared_name" : "28 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 966,
        "Column_4" : 45,
        "BEND_MAP_ID" : 966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "964",
        "source" : "270",
        "target" : "334",
        "shared_name" : "28 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 964,
        "Column_4" : 36,
        "BEND_MAP_ID" : 964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "962",
        "source" : "270",
        "target" : "500",
        "shared_name" : "28 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 962,
        "Column_4" : 12,
        "BEND_MAP_ID" : 962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "960",
        "source" : "270",
        "target" : "294",
        "shared_name" : "28 (interacts with) Spice",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Spice",
        "interaction" : "interacts with",
        "SUID" : 960,
        "Column_4" : 19,
        "BEND_MAP_ID" : 960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "958",
        "source" : "270",
        "target" : "504",
        "shared_name" : "28 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 958,
        "Column_4" : 3,
        "BEND_MAP_ID" : 958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "956",
        "source" : "270",
        "target" : "318",
        "shared_name" : "28 (interacts with) Squalo",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Squalo",
        "interaction" : "interacts with",
        "SUID" : 956,
        "Column_4" : 9,
        "BEND_MAP_ID" : 956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "954",
        "source" : "270",
        "target" : "316",
        "shared_name" : "28 (interacts with) Tiziano",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Tiziano",
        "interaction" : "interacts with",
        "SUID" : 954,
        "Column_4" : 1,
        "BEND_MAP_ID" : 954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "952",
        "source" : "270",
        "target" : "506",
        "shared_name" : "28 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 952,
        "Column_4" : 11,
        "BEND_MAP_ID" : 952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "950",
        "source" : "270",
        "target" : "306",
        "shared_name" : "28 (interacts with) Rome___a_m_,Nara",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Rome___a_m_,Nara",
        "interaction" : "interacts with",
        "SUID" : 950,
        "Column_4" : 1,
        "BEND_MAP_ID" : 950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "948",
        "source" : "270",
        "target" : "606",
        "shared_name" : "28 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 948,
        "Column_4" : 1,
        "BEND_MAP_ID" : 948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "946",
        "source" : "270",
        "target" : "322",
        "shared_name" : "28 (interacts with) Doppio",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Doppio",
        "interaction" : "interacts with",
        "SUID" : 946,
        "Column_4" : 6,
        "BEND_MAP_ID" : 946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "944",
        "source" : "270",
        "target" : "406",
        "shared_name" : "28 (interacts with) Risotto",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Risotto",
        "interaction" : "interacts with",
        "SUID" : 944,
        "Column_4" : 7,
        "BEND_MAP_ID" : 944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "942",
        "source" : "270",
        "target" : "272",
        "shared_name" : "28 (interacts with) Dopp",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Dopp",
        "interaction" : "interacts with",
        "SUID" : 942,
        "Column_4" : 3,
        "BEND_MAP_ID" : 942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "940",
        "source" : "270",
        "target" : "350",
        "shared_name" : "28 (interacts with) Riso",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Riso",
        "interaction" : "interacts with",
        "SUID" : 940,
        "Column_4" : 9,
        "BEND_MAP_ID" : 940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "938",
        "source" : "270",
        "target" : "600",
        "shared_name" : "28 (interacts with) Kid",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Kid",
        "interaction" : "interacts with",
        "SUID" : 938,
        "Column_4" : 5,
        "BEND_MAP_ID" : 938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "936",
        "source" : "270",
        "target" : "266",
        "shared_name" : "28 (interacts with) Dop",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Dop",
        "interaction" : "interacts with",
        "SUID" : 936,
        "Column_4" : 1,
        "BEND_MAP_ID" : 936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "934",
        "source" : "270",
        "target" : "602",
        "shared_name" : "28 (interacts with) Cop",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Cop",
        "interaction" : "interacts with",
        "SUID" : 934,
        "Column_4" : 7,
        "BEND_MAP_ID" : 934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "932",
        "source" : "270",
        "target" : "260",
        "shared_name" : "28 (interacts with) What_the_hell_is",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) What_the_hell_is",
        "interaction" : "interacts with",
        "SUID" : 932,
        "Column_4" : 22,
        "BEND_MAP_ID" : 932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "930",
        "source" : "270",
        "target" : "590",
        "shared_name" : "28 (interacts with) Giorno",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Giorno",
        "interaction" : "interacts with",
        "SUID" : 930,
        "Column_4" : 13,
        "BEND_MAP_ID" : 930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "928",
        "source" : "270",
        "target" : "430",
        "shared_name" : "28 (interacts with) Peri",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Peri",
        "interaction" : "interacts with",
        "SUID" : 928,
        "Column_4" : 1,
        "BEND_MAP_ID" : 928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "926",
        "source" : "270",
        "target" : "292",
        "shared_name" : "28 (interacts with) Spicy",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Spicy",
        "interaction" : "interacts with",
        "SUID" : 926,
        "Column_4" : 1,
        "BEND_MAP_ID" : 926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "924",
        "source" : "270",
        "target" : "514",
        "shared_name" : "28 (interacts with) Rome___a_m_,Sign",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Rome___a_m_,Sign",
        "interaction" : "interacts with",
        "SUID" : 924,
        "Column_4" : 2,
        "BEND_MAP_ID" : 924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "922",
        "source" : "270",
        "target" : "470",
        "shared_name" : "28 (interacts with) Baaaaaa,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Baaaaaa,Sfx",
        "interaction" : "interacts with",
        "SUID" : 922,
        "Column_4" : 1,
        "BEND_MAP_ID" : 922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "920",
        "source" : "270",
        "target" : "258",
        "shared_name" : "28 (interacts with) What_the_hell_is,Fugo",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) What_the_hell_is,Fugo",
        "interaction" : "interacts with",
        "SUID" : 920,
        "Column_4" : 1,
        "BEND_MAP_ID" : 920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "918",
        "source" : "270",
        "target" : "480",
        "shared_name" : "28 (interacts with) Sfx",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Sfx",
        "interaction" : "interacts with",
        "SUID" : 918,
        "Column_4" : 6,
        "BEND_MAP_ID" : 918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "916",
        "source" : "270",
        "target" : "558",
        "shared_name" : "28 (interacts with) Gold",
        "shared_interaction" : "interacts with",
        "name" : "28 (interacts with) Gold",
        "interaction" : "interacts with",
        "SUID" : 916,
        "Column_4" : 1,
        "BEND_MAP_ID" : 916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "914",
        "source" : "256",
        "target" : "576",
        "shared_name" : "29 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 914,
        "Column_4" : 41,
        "BEND_MAP_ID" : 914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "912",
        "source" : "256",
        "target" : "434",
        "shared_name" : "29 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 912,
        "Column_4" : 9,
        "BEND_MAP_ID" : 912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "910",
        "source" : "256",
        "target" : "282",
        "shared_name" : "29 (interacts with) Man",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Man",
        "interaction" : "interacts with",
        "SUID" : 910,
        "Column_4" : 73,
        "BEND_MAP_ID" : 910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "908",
        "source" : "256",
        "target" : "504",
        "shared_name" : "29 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 908,
        "Column_4" : 14,
        "BEND_MAP_ID" : 908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "906",
        "source" : "256",
        "target" : "266",
        "shared_name" : "29 (interacts with) Dop",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Dop",
        "interaction" : "interacts with",
        "SUID" : 906,
        "Column_4" : 21,
        "BEND_MAP_ID" : 906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "904",
        "source" : "256",
        "target" : "334",
        "shared_name" : "29 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 904,
        "Column_4" : 37,
        "BEND_MAP_ID" : 904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "902",
        "source" : "256",
        "target" : "512",
        "shared_name" : "29 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 902,
        "Column_4" : 22,
        "BEND_MAP_ID" : 902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "900",
        "source" : "256",
        "target" : "506",
        "shared_name" : "29 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 900,
        "Column_4" : 32,
        "BEND_MAP_ID" : 900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "898",
        "source" : "256",
        "target" : "254",
        "shared_name" : "29 (interacts with) Drunk",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Drunk",
        "interaction" : "interacts with",
        "SUID" : 898,
        "Column_4" : 19,
        "BEND_MAP_ID" : 898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "896",
        "source" : "256",
        "target" : "252",
        "shared_name" : "29 (interacts with) Cio",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Cio",
        "interaction" : "interacts with",
        "SUID" : 896,
        "Column_4" : 15,
        "BEND_MAP_ID" : 896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "894",
        "source" : "256",
        "target" : "250",
        "shared_name" : "29 (interacts with) Eulogy_Predicts_ - Copy,Sign",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Eulogy_Predicts_ - Copy,Sign",
        "interaction" : "interacts with",
        "SUID" : 894,
        "Column_4" : 1,
        "BEND_MAP_ID" : 894,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "892",
        "source" : "256",
        "target" : "248",
        "shared_name" : "29 (interacts with) Eulogy_Predicts_,Sign",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Eulogy_Predicts_,Sign",
        "interaction" : "interacts with",
        "SUID" : 892,
        "Column_4" : 1,
        "BEND_MAP_ID" : 892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "890",
        "source" : "256",
        "target" : "604",
        "shared_name" : "29 (interacts with) Girl",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Girl",
        "interaction" : "interacts with",
        "SUID" : 890,
        "Column_4" : 1,
        "BEND_MAP_ID" : 890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "888",
        "source" : "256",
        "target" : "246",
        "shared_name" : "29 (interacts with) Crunch,Sign",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Crunch,Sign",
        "interaction" : "interacts with",
        "SUID" : 888,
        "Column_4" : 1,
        "BEND_MAP_ID" : 888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "886",
        "source" : "256",
        "target" : "456",
        "shared_name" : "29 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 886,
        "Column_4" : 1,
        "BEND_MAP_ID" : 886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "884",
        "source" : "244",
        "target" : "506",
        "shared_name" : "30 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 884,
        "Column_4" : 67,
        "BEND_MAP_ID" : 884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "882",
        "source" : "244",
        "target" : "504",
        "shared_name" : "30 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 882,
        "Column_4" : 9,
        "BEND_MAP_ID" : 882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "880",
        "source" : "244",
        "target" : "456",
        "shared_name" : "30 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 880,
        "Column_4" : 3,
        "BEND_MAP_ID" : 880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "878",
        "source" : "244",
        "target" : "576",
        "shared_name" : "30 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 878,
        "Column_4" : 86,
        "BEND_MAP_ID" : 878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "876",
        "source" : "244",
        "target" : "252",
        "shared_name" : "30 (interacts with) Cio",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Cio",
        "interaction" : "interacts with",
        "SUID" : 876,
        "Column_4" : 42,
        "BEND_MAP_ID" : 876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "874",
        "source" : "244",
        "target" : "434",
        "shared_name" : "30 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 874,
        "Column_4" : 8,
        "BEND_MAP_ID" : 874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "872",
        "source" : "244",
        "target" : "512",
        "shared_name" : "30 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 872,
        "Column_4" : 12,
        "BEND_MAP_ID" : 872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "870",
        "source" : "244",
        "target" : "242",
        "shared_name" : "30 (interacts with) Zip",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Zip",
        "interaction" : "interacts with",
        "SUID" : 870,
        "Column_4" : 4,
        "BEND_MAP_ID" : 870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "868",
        "source" : "244",
        "target" : "580",
        "shared_name" : "30 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 868,
        "Column_4" : 2,
        "BEND_MAP_ID" : 868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "866",
        "source" : "244",
        "target" : "240",
        "shared_name" : "30 (interacts with) Secco",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Secco",
        "interaction" : "interacts with",
        "SUID" : 866,
        "Column_4" : 21,
        "BEND_MAP_ID" : 866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "864",
        "source" : "244",
        "target" : "238",
        "shared_name" : "30 (interacts with) Giio",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Giio",
        "interaction" : "interacts with",
        "SUID" : 864,
        "Column_4" : 1,
        "BEND_MAP_ID" : 864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "862",
        "source" : "244",
        "target" : "606",
        "shared_name" : "30 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "30 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 862,
        "Column_4" : 3,
        "BEND_MAP_ID" : 862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "860",
        "source" : "236",
        "target" : "576",
        "shared_name" : "31 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 860,
        "Column_4" : 17,
        "BEND_MAP_ID" : 860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "858",
        "source" : "236",
        "target" : "252",
        "shared_name" : "31 (interacts with) Cio",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) Cio",
        "interaction" : "interacts with",
        "SUID" : 858,
        "Column_4" : 85,
        "BEND_MAP_ID" : 858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "856",
        "source" : "236",
        "target" : "506",
        "shared_name" : "31 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 856,
        "Column_4" : 12,
        "BEND_MAP_ID" : 856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "854",
        "source" : "236",
        "target" : "240",
        "shared_name" : "31 (interacts with) Secco",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) Secco",
        "interaction" : "interacts with",
        "SUID" : 854,
        "Column_4" : 36,
        "BEND_MAP_ID" : 854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "852",
        "source" : "236",
        "target" : "456",
        "shared_name" : "31 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 852,
        "Column_4" : 1,
        "BEND_MAP_ID" : 852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "850",
        "source" : "236",
        "target" : "442",
        "shared_name" : "31 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 850,
        "Column_4" : 34,
        "BEND_MAP_ID" : 850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "848",
        "source" : "236",
        "target" : "444",
        "shared_name" : "31 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 848,
        "Column_4" : 13,
        "BEND_MAP_ID" : 848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "846",
        "source" : "236",
        "target" : "448",
        "shared_name" : "31 (interacts with) Six",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) Six",
        "interaction" : "interacts with",
        "SUID" : 846,
        "Column_4" : 4,
        "BEND_MAP_ID" : 846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "844",
        "source" : "236",
        "target" : "340",
        "shared_name" : "31 (interacts with) Both",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) Both",
        "interaction" : "interacts with",
        "SUID" : 844,
        "Column_4" : 1,
        "BEND_MAP_ID" : 844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "842",
        "source" : "236",
        "target" : "494",
        "shared_name" : "31 (interacts with) Msita",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) Msita",
        "interaction" : "interacts with",
        "SUID" : 842,
        "Column_4" : 1,
        "BEND_MAP_ID" : 842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "840",
        "source" : "236",
        "target" : "580",
        "shared_name" : "31 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "31 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 840,
        "Column_4" : 3,
        "BEND_MAP_ID" : 840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "838",
        "source" : "234",
        "target" : "240",
        "shared_name" : "32 (interacts with) Secco",
        "shared_interaction" : "interacts with",
        "name" : "32 (interacts with) Secco",
        "interaction" : "interacts with",
        "SUID" : 838,
        "Column_4" : 177,
        "BEND_MAP_ID" : 838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "836",
        "source" : "234",
        "target" : "576",
        "shared_name" : "32 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "32 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 836,
        "Column_4" : 67,
        "BEND_MAP_ID" : 836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "834",
        "source" : "234",
        "target" : "606",
        "shared_name" : "32 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "32 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 834,
        "Column_4" : 7,
        "BEND_MAP_ID" : 834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "832",
        "source" : "234",
        "target" : "252",
        "shared_name" : "32 (interacts with) Cio",
        "shared_interaction" : "interacts with",
        "name" : "32 (interacts with) Cio",
        "interaction" : "interacts with",
        "SUID" : 832,
        "Column_4" : 14,
        "BEND_MAP_ID" : 832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "830",
        "source" : "234",
        "target" : "232",
        "shared_name" : "32 (interacts with) Pol",
        "shared_interaction" : "interacts with",
        "name" : "32 (interacts with) Pol",
        "interaction" : "interacts with",
        "SUID" : 830,
        "Column_4" : 21,
        "BEND_MAP_ID" : 830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "828",
        "source" : "234",
        "target" : "230",
        "shared_name" : "32 (interacts with) J_P__Polnareff__,Sign",
        "shared_interaction" : "interacts with",
        "name" : "32 (interacts with) J_P__Polnareff__,Sign",
        "interaction" : "interacts with",
        "SUID" : 828,
        "Column_4" : 1,
        "BEND_MAP_ID" : 828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "826",
        "source" : "234",
        "target" : "580",
        "shared_name" : "32 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "32 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 826,
        "Column_4" : 2,
        "BEND_MAP_ID" : 826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "824",
        "source" : "234",
        "target" : "272",
        "shared_name" : "32 (interacts with) Dopp",
        "shared_interaction" : "interacts with",
        "name" : "32 (interacts with) Dopp",
        "interaction" : "interacts with",
        "SUID" : 824,
        "Column_4" : 9,
        "BEND_MAP_ID" : 824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "822",
        "source" : "228",
        "target" : "576",
        "shared_name" : "33 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 822,
        "Column_4" : 51,
        "BEND_MAP_ID" : 822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "820",
        "source" : "228",
        "target" : "272",
        "shared_name" : "33 (interacts with) Dopp",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Dopp",
        "interaction" : "interacts with",
        "SUID" : 820,
        "Column_4" : 60,
        "BEND_MAP_ID" : 820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "818",
        "source" : "228",
        "target" : "594",
        "shared_name" : "33 (interacts with) Driver",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Driver",
        "interaction" : "interacts with",
        "SUID" : 818,
        "Column_4" : 1,
        "BEND_MAP_ID" : 818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "816",
        "source" : "228",
        "target" : "434",
        "shared_name" : "33 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 816,
        "Column_4" : 8,
        "BEND_MAP_ID" : 816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "814",
        "source" : "228",
        "target" : "504",
        "shared_name" : "33 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 814,
        "Column_4" : 4,
        "BEND_MAP_ID" : 814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "812",
        "source" : "228",
        "target" : "506",
        "shared_name" : "33 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 812,
        "Column_4" : 3,
        "BEND_MAP_ID" : 812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "810",
        "source" : "228",
        "target" : "334",
        "shared_name" : "33 (interacts with) Boss",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Boss",
        "interaction" : "interacts with",
        "SUID" : 810,
        "Column_4" : 50,
        "BEND_MAP_ID" : 810,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "808",
        "source" : "228",
        "target" : "580",
        "shared_name" : "33 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 808,
        "Column_4" : 2,
        "BEND_MAP_ID" : 808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "806",
        "source" : "228",
        "target" : "232",
        "shared_name" : "33 (interacts with) Pol",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Pol",
        "interaction" : "interacts with",
        "SUID" : 806,
        "Column_4" : 58,
        "BEND_MAP_ID" : 806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "804",
        "source" : "228",
        "target" : "340",
        "shared_name" : "33 (interacts with) Both",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Both",
        "interaction" : "interacts with",
        "SUID" : 804,
        "Column_4" : 1,
        "BEND_MAP_ID" : 804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "802",
        "source" : "228",
        "target" : "344",
        "shared_name" : "33 (interacts with) Dia",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Dia",
        "interaction" : "interacts with",
        "SUID" : 802,
        "Column_4" : 42,
        "BEND_MAP_ID" : 802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "800",
        "source" : "226",
        "target" : "344",
        "shared_name" : "34 (interacts with) Dia",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Dia",
        "interaction" : "interacts with",
        "SUID" : 800,
        "Column_4" : 12,
        "BEND_MAP_ID" : 800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "798",
        "source" : "226",
        "target" : "504",
        "shared_name" : "34 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 798,
        "Column_4" : 2,
        "BEND_MAP_ID" : 798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "796",
        "source" : "226",
        "target" : "224",
        "shared_name" : "34 (interacts with) No_one_can_escap,Op subs",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) No_one_can_escap,Op subs",
        "interaction" : "interacts with",
        "SUID" : 796,
        "Column_4" : 4,
        "BEND_MAP_ID" : 796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "794",
        "source" : "226",
        "target" : "434",
        "shared_name" : "34 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 794,
        "Column_4" : 43,
        "BEND_MAP_ID" : 794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "792",
        "source" : "226",
        "target" : "246",
        "shared_name" : "34 (interacts with) Crunch,Sign",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Crunch,Sign",
        "interaction" : "interacts with",
        "SUID" : 792,
        "Column_4" : 1,
        "BEND_MAP_ID" : 792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "790",
        "source" : "226",
        "target" : "506",
        "shared_name" : "34 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 790,
        "Column_4" : 35,
        "BEND_MAP_ID" : 790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "source" : "226",
        "target" : "340",
        "shared_name" : "34 (interacts with) Both",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Both",
        "interaction" : "interacts with",
        "SUID" : 788,
        "Column_4" : 1,
        "BEND_MAP_ID" : 788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "786",
        "source" : "226",
        "target" : "512",
        "shared_name" : "34 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 786,
        "Column_4" : 28,
        "BEND_MAP_ID" : 786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "784",
        "source" : "226",
        "target" : "456",
        "shared_name" : "34 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 784,
        "Column_4" : 2,
        "BEND_MAP_ID" : 784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "782",
        "source" : "226",
        "target" : "602",
        "shared_name" : "34 (interacts with) Cop",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Cop",
        "interaction" : "interacts with",
        "SUID" : 782,
        "Column_4" : 3,
        "BEND_MAP_ID" : 782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "780",
        "source" : "226",
        "target" : "606",
        "shared_name" : "34 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 780,
        "Column_4" : 2,
        "BEND_MAP_ID" : 780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "778",
        "source" : "226",
        "target" : "560",
        "shared_name" : "34 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 778,
        "Column_4" : 1,
        "BEND_MAP_ID" : 778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "776",
        "source" : "226",
        "target" : "222",
        "shared_name" : "34 (interacts with) Turtle",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Turtle",
        "interaction" : "interacts with",
        "SUID" : 776,
        "Column_4" : 81,
        "BEND_MAP_ID" : 776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "774",
        "source" : "226",
        "target" : "220",
        "shared_name" : "34 (interacts with) Who_swapped_with,Sign",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Who_swapped_with,Sign",
        "interaction" : "interacts with",
        "SUID" : 774,
        "Column_4" : 1,
        "BEND_MAP_ID" : 774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "772",
        "source" : "226",
        "target" : "218",
        "shared_name" : "34 (interacts with) Mista___________,Sign",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Mista___________,Sign",
        "interaction" : "interacts with",
        "SUID" : 772,
        "Column_4" : 4,
        "BEND_MAP_ID" : 772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "source" : "226",
        "target" : "216",
        "shared_name" : "34 (interacts with) Turtrle",
        "shared_interaction" : "interacts with",
        "name" : "34 (interacts with) Turtrle",
        "interaction" : "interacts with",
        "SUID" : 770,
        "Column_4" : 1,
        "BEND_MAP_ID" : 770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "768",
        "source" : "214",
        "target" : "222",
        "shared_name" : "35 (interacts with) Turtle",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Turtle",
        "interaction" : "interacts with",
        "SUID" : 768,
        "Column_4" : 62,
        "BEND_MAP_ID" : 768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "766",
        "source" : "214",
        "target" : "506",
        "shared_name" : "35 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 766,
        "Column_4" : 17,
        "BEND_MAP_ID" : 766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "source" : "214",
        "target" : "512",
        "shared_name" : "35 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 764,
        "Column_4" : 25,
        "BEND_MAP_ID" : 764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "762",
        "source" : "214",
        "target" : "224",
        "shared_name" : "35 (interacts with) No_one_can_escap,Op subs",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) No_one_can_escap,Op subs",
        "interaction" : "interacts with",
        "SUID" : 762,
        "Column_4" : 4,
        "BEND_MAP_ID" : 762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "760",
        "source" : "214",
        "target" : "344",
        "shared_name" : "35 (interacts with) Dia",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Dia",
        "interaction" : "interacts with",
        "SUID" : 760,
        "Column_4" : 51,
        "BEND_MAP_ID" : 760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "source" : "214",
        "target" : "504",
        "shared_name" : "35 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 758,
        "Column_4" : 19,
        "BEND_MAP_ID" : 758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "756",
        "source" : "214",
        "target" : "434",
        "shared_name" : "35 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 756,
        "Column_4" : 50,
        "BEND_MAP_ID" : 756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "754",
        "source" : "214",
        "target" : "458",
        "shared_name" : "35 (interacts with) B*llet",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) B*llet",
        "interaction" : "interacts with",
        "SUID" : 754,
        "Column_4" : 6,
        "BEND_MAP_ID" : 754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "source" : "214",
        "target" : "374",
        "shared_name" : "35 (interacts with) Three",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Three",
        "interaction" : "interacts with",
        "SUID" : 752,
        "Column_4" : 1,
        "BEND_MAP_ID" : 752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "750",
        "source" : "214",
        "target" : "444",
        "shared_name" : "35 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 750,
        "Column_4" : 2,
        "BEND_MAP_ID" : 750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "748",
        "source" : "214",
        "target" : "212",
        "shared_name" : "35 (interacts with) Dog",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Dog",
        "interaction" : "interacts with",
        "SUID" : 748,
        "Column_4" : 1,
        "BEND_MAP_ID" : 748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "746",
        "source" : "214",
        "target" : "354",
        "shared_name" : "35 (interacts with) Baby",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Baby",
        "interaction" : "interacts with",
        "SUID" : 746,
        "Column_4" : 1,
        "BEND_MAP_ID" : 746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "744",
        "source" : "214",
        "target" : "442",
        "shared_name" : "35 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 744,
        "Column_4" : 1,
        "BEND_MAP_ID" : 744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "742",
        "source" : "214",
        "target" : "440",
        "shared_name" : "35 (interacts with) Seven",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Seven",
        "interaction" : "interacts with",
        "SUID" : 742,
        "Column_4" : 2,
        "BEND_MAP_ID" : 742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "source" : "214",
        "target" : "210",
        "shared_name" : "35 (interacts with) Narancia",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Narancia",
        "interaction" : "interacts with",
        "SUID" : 740,
        "Column_4" : 2,
        "BEND_MAP_ID" : 740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "738",
        "source" : "214",
        "target" : "580",
        "shared_name" : "35 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 738,
        "Column_4" : 2,
        "BEND_MAP_ID" : 738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "736",
        "source" : "214",
        "target" : "208",
        "shared_name" : "35 (interacts with) Crunch,Trish",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Crunch,Trish",
        "interaction" : "interacts with",
        "SUID" : 736,
        "Column_4" : 1,
        "BEND_MAP_ID" : 736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "source" : "214",
        "target" : "606",
        "shared_name" : "35 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "35 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 734,
        "Column_4" : 2,
        "BEND_MAP_ID" : 734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "732",
        "source" : "206",
        "target" : "576",
        "shared_name" : "36 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 732,
        "Column_4" : 7,
        "BEND_MAP_ID" : 732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "730",
        "source" : "206",
        "target" : "272",
        "shared_name" : "36 (interacts with) Dopp",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Dopp",
        "interaction" : "interacts with",
        "SUID" : 730,
        "Column_4" : 3,
        "BEND_MAP_ID" : 730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "source" : "206",
        "target" : "224",
        "shared_name" : "36 (interacts with) No_one_can_escap,Op subs",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) No_one_can_escap,Op subs",
        "interaction" : "interacts with",
        "SUID" : 728,
        "Column_4" : 4,
        "BEND_MAP_ID" : 728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "726",
        "source" : "206",
        "target" : "222",
        "shared_name" : "36 (interacts with) Turtle",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Turtle",
        "interaction" : "interacts with",
        "SUID" : 726,
        "Column_4" : 27,
        "BEND_MAP_ID" : 726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "724",
        "source" : "206",
        "target" : "506",
        "shared_name" : "36 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 724,
        "Column_4" : 17,
        "BEND_MAP_ID" : 724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "722",
        "source" : "206",
        "target" : "344",
        "shared_name" : "36 (interacts with) Dia",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Dia",
        "interaction" : "interacts with",
        "SUID" : 722,
        "Column_4" : 45,
        "BEND_MAP_ID" : 722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "720",
        "source" : "206",
        "target" : "504",
        "shared_name" : "36 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 720,
        "Column_4" : 5,
        "BEND_MAP_ID" : 720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "718",
        "source" : "206",
        "target" : "434",
        "shared_name" : "36 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 718,
        "Column_4" : 71,
        "BEND_MAP_ID" : 718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "source" : "206",
        "target" : "442",
        "shared_name" : "36 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 716,
        "Column_4" : 1,
        "BEND_MAP_ID" : 716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "714",
        "source" : "206",
        "target" : "458",
        "shared_name" : "36 (interacts with) B*llet",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) B*llet",
        "interaction" : "interacts with",
        "SUID" : 714,
        "Column_4" : 12,
        "BEND_MAP_ID" : 714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "712",
        "source" : "206",
        "target" : "204",
        "shared_name" : "36 (interacts with) King",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) King",
        "interaction" : "interacts with",
        "SUID" : 712,
        "Column_4" : 49,
        "BEND_MAP_ID" : 712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "source" : "206",
        "target" : "202",
        "shared_name" : "36 (interacts with) Who_swapped_with,King",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Who_swapped_with,King",
        "interaction" : "interacts with",
        "SUID" : 710,
        "Column_4" : 1,
        "BEND_MAP_ID" : 710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "708",
        "source" : "206",
        "target" : "200",
        "shared_name" : "36 (interacts with) Bucciarati,Sign",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Bucciarati,Sign",
        "interaction" : "interacts with",
        "SUID" : 708,
        "Column_4" : 6,
        "BEND_MAP_ID" : 708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "706",
        "source" : "206",
        "target" : "198",
        "shared_name" : "36 (interacts with) Bull",
        "shared_interaction" : "interacts with",
        "name" : "36 (interacts with) Bull",
        "interaction" : "interacts with",
        "SUID" : 706,
        "Column_4" : 3,
        "BEND_MAP_ID" : 706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "source" : "196",
        "target" : "204",
        "shared_name" : "37 (interacts with) King",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) King",
        "interaction" : "interacts with",
        "SUID" : 704,
        "Column_4" : 33,
        "BEND_MAP_ID" : 704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "702",
        "source" : "196",
        "target" : "194",
        "shared_name" : "37 (interacts with) Crunch,sfx",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Crunch,sfx",
        "interaction" : "interacts with",
        "SUID" : 702,
        "Column_4" : 1,
        "BEND_MAP_ID" : 702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "700",
        "source" : "196",
        "target" : "344",
        "shared_name" : "37 (interacts with) Dia",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Dia",
        "interaction" : "interacts with",
        "SUID" : 700,
        "Column_4" : 117,
        "BEND_MAP_ID" : 700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "source" : "196",
        "target" : "224",
        "shared_name" : "37 (interacts with) No_one_can_escap,Op subs",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) No_one_can_escap,Op subs",
        "interaction" : "interacts with",
        "SUID" : 698,
        "Column_4" : 4,
        "BEND_MAP_ID" : 698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "696",
        "source" : "196",
        "target" : "434",
        "shared_name" : "37 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 696,
        "Column_4" : 29,
        "BEND_MAP_ID" : 696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "694",
        "source" : "196",
        "target" : "442",
        "shared_name" : "37 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 694,
        "Column_4" : 1,
        "BEND_MAP_ID" : 694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "source" : "196",
        "target" : "376",
        "shared_name" : "37 (interacts with) Two",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Two",
        "interaction" : "interacts with",
        "SUID" : 692,
        "Column_4" : 1,
        "BEND_MAP_ID" : 692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "690",
        "source" : "196",
        "target" : "444",
        "shared_name" : "37 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 690,
        "Column_4" : 1,
        "BEND_MAP_ID" : 690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "688",
        "source" : "196",
        "target" : "506",
        "shared_name" : "37 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 688,
        "Column_4" : 21,
        "BEND_MAP_ID" : 688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "686",
        "source" : "196",
        "target" : "576",
        "shared_name" : "37 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 686,
        "Column_4" : 25,
        "BEND_MAP_ID" : 686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "684",
        "source" : "196",
        "target" : "458",
        "shared_name" : "37 (interacts with) B*llet",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) B*llet",
        "interaction" : "interacts with",
        "SUID" : 684,
        "Column_4" : 5,
        "BEND_MAP_ID" : 684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "682",
        "source" : "196",
        "target" : "580",
        "shared_name" : "37 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 682,
        "Column_4" : 2,
        "BEND_MAP_ID" : 682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "source" : "196",
        "target" : "606",
        "shared_name" : "37 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 680,
        "Column_4" : 1,
        "BEND_MAP_ID" : 680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "678",
        "source" : "196",
        "target" : "290",
        "shared_name" : "37 (interacts with) Diavolo",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Diavolo",
        "interaction" : "interacts with",
        "SUID" : 678,
        "Column_4" : 2,
        "BEND_MAP_ID" : 678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "676",
        "source" : "196",
        "target" : "348",
        "shared_name" : "37 (interacts with) GW",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) GW",
        "interaction" : "interacts with",
        "SUID" : 676,
        "Column_4" : 1,
        "BEND_MAP_ID" : 676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "source" : "196",
        "target" : "192",
        "shared_name" : "37 (interacts with) Gw",
        "shared_interaction" : "interacts with",
        "name" : "37 (interacts with) Gw",
        "interaction" : "interacts with",
        "SUID" : 674,
        "Column_4" : 11,
        "BEND_MAP_ID" : 674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "672",
        "source" : "190",
        "target" : "506",
        "shared_name" : "38 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 672,
        "Column_4" : 72,
        "BEND_MAP_ID" : 672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "670",
        "source" : "190",
        "target" : "512",
        "shared_name" : "38 (interacts with) Nara",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Nara",
        "interaction" : "interacts with",
        "SUID" : 670,
        "Column_4" : 9,
        "BEND_MAP_ID" : 670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "source" : "190",
        "target" : "508",
        "shared_name" : "38 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 668,
        "Column_4" : 22,
        "BEND_MAP_ID" : 668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "666",
        "source" : "190",
        "target" : "504",
        "shared_name" : "38 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 666,
        "Column_4" : 4,
        "BEND_MAP_ID" : 666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "664",
        "source" : "190",
        "target" : "344",
        "shared_name" : "38 (interacts with) Dia",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Dia",
        "interaction" : "interacts with",
        "SUID" : 664,
        "Column_4" : 51,
        "BEND_MAP_ID" : 664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "source" : "190",
        "target" : "224",
        "shared_name" : "38 (interacts with) No_one_can_escap,Op subs",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) No_one_can_escap,Op subs",
        "interaction" : "interacts with",
        "SUID" : 662,
        "Column_4" : 2,
        "BEND_MAP_ID" : 662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "660",
        "source" : "190",
        "target" : "434",
        "shared_name" : "38 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 660,
        "Column_4" : 11,
        "BEND_MAP_ID" : 660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "658",
        "source" : "190",
        "target" : "606",
        "shared_name" : "38 (interacts with) Guy",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Guy",
        "interaction" : "interacts with",
        "SUID" : 658,
        "Column_4" : 48,
        "BEND_MAP_ID" : 658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "source" : "190",
        "target" : "560",
        "shared_name" : "38 (interacts with) Lady",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Lady",
        "interaction" : "interacts with",
        "SUID" : 656,
        "Column_4" : 12,
        "BEND_MAP_ID" : 656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "654",
        "source" : "190",
        "target" : "604",
        "shared_name" : "38 (interacts with) Girl",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Girl",
        "interaction" : "interacts with",
        "SUID" : 654,
        "Column_4" : 1,
        "BEND_MAP_ID" : 654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "652",
        "source" : "190",
        "target" : "576",
        "shared_name" : "38 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 652,
        "Column_4" : 54,
        "BEND_MAP_ID" : 652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "650",
        "source" : "190",
        "target" : "580",
        "shared_name" : "38 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 650,
        "Column_4" : 2,
        "BEND_MAP_ID" : 650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "648",
        "source" : "190",
        "target" : "500",
        "shared_name" : "38 (interacts with) Abba",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Abba",
        "interaction" : "interacts with",
        "SUID" : 648,
        "Column_4" : 4,
        "BEND_MAP_ID" : 648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "646",
        "source" : "190",
        "target" : "188",
        "shared_name" : "38 (interacts with) Bad_luck,Sign",
        "shared_interaction" : "interacts with",
        "name" : "38 (interacts with) Bad_luck,Sign",
        "interaction" : "interacts with",
        "SUID" : 646,
        "Column_4" : 3,
        "BEND_MAP_ID" : 646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "644",
        "source" : "186",
        "target" : "184",
        "shared_name" : "39 (interacts with) Op subs",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Op subs",
        "interaction" : "interacts with",
        "SUID" : 644,
        "Column_4" : 2,
        "BEND_MAP_ID" : 644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "642",
        "source" : "186",
        "target" : "506",
        "shared_name" : "39 (interacts with) Mista",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Mista",
        "interaction" : "interacts with",
        "SUID" : 642,
        "Column_4" : 117,
        "BEND_MAP_ID" : 642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "640",
        "source" : "186",
        "target" : "182",
        "shared_name" : "39 (interacts with) Sco",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Sco",
        "interaction" : "interacts with",
        "SUID" : 640,
        "Column_4" : 63,
        "BEND_MAP_ID" : 640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "source" : "186",
        "target" : "458",
        "shared_name" : "39 (interacts with) B*llet",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) B*llet",
        "interaction" : "interacts with",
        "SUID" : 638,
        "Column_4" : 14,
        "BEND_MAP_ID" : 638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "636",
        "source" : "186",
        "target" : "442",
        "shared_name" : "39 (interacts with) Five",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Five",
        "interaction" : "interacts with",
        "SUID" : 636,
        "Column_4" : 2,
        "BEND_MAP_ID" : 636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "634",
        "source" : "186",
        "target" : "508",
        "shared_name" : "39 (interacts with) Fugo",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Fugo",
        "interaction" : "interacts with",
        "SUID" : 634,
        "Column_4" : 15,
        "BEND_MAP_ID" : 634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "source" : "186",
        "target" : "188",
        "shared_name" : "39 (interacts with) Bad_luck,Sign",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Bad_luck,Sign",
        "interaction" : "interacts with",
        "SUID" : 632,
        "Column_4" : 1,
        "BEND_MAP_ID" : 632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "630",
        "source" : "186",
        "target" : "580",
        "shared_name" : "39 (interacts with) Sign",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Sign",
        "interaction" : "interacts with",
        "SUID" : 630,
        "Column_4" : 2,
        "BEND_MAP_ID" : 630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "628",
        "source" : "186",
        "target" : "448",
        "shared_name" : "39 (interacts with) Six",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Six",
        "interaction" : "interacts with",
        "SUID" : 628,
        "Column_4" : 2,
        "BEND_MAP_ID" : 628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "source" : "186",
        "target" : "444",
        "shared_name" : "39 (interacts with) One",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) One",
        "interaction" : "interacts with",
        "SUID" : 626,
        "Column_4" : 3,
        "BEND_MAP_ID" : 626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "624",
        "source" : "186",
        "target" : "456",
        "shared_name" : "39 (interacts with) B*ll*ts",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) B*ll*ts",
        "interaction" : "interacts with",
        "SUID" : 624,
        "Column_4" : 1,
        "BEND_MAP_ID" : 624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "622",
        "source" : "186",
        "target" : "576",
        "shared_name" : "39 (interacts with) Bruno",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Bruno",
        "interaction" : "interacts with",
        "SUID" : 622,
        "Column_4" : 17,
        "BEND_MAP_ID" : 622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "620",
        "source" : "186",
        "target" : "424",
        "shared_name" : "39 (interacts with) MistA",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) MistA",
        "interaction" : "interacts with",
        "SUID" : 620,
        "Column_4" : 1,
        "BEND_MAP_ID" : 620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "618",
        "source" : "186",
        "target" : "494",
        "shared_name" : "39 (interacts with) Msita",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Msita",
        "interaction" : "interacts with",
        "SUID" : 618,
        "Column_4" : 1,
        "BEND_MAP_ID" : 618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "616",
        "source" : "186",
        "target" : "434",
        "shared_name" : "39 (interacts with) Trish",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Trish",
        "interaction" : "interacts with",
        "SUID" : 616,
        "Column_4" : 12,
        "BEND_MAP_ID" : 616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "source" : "186",
        "target" : "504",
        "shared_name" : "39 (interacts with) Crunch,Sfx",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Crunch,Sfx",
        "interaction" : "interacts with",
        "SUID" : 614,
        "Column_4" : 1,
        "BEND_MAP_ID" : 614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "612",
        "source" : "186",
        "target" : "222",
        "shared_name" : "39 (interacts with) Turtle",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Turtle",
        "interaction" : "interacts with",
        "SUID" : 612,
        "Column_4" : 2,
        "BEND_MAP_ID" : 612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "610",
        "source" : "186",
        "target" : "232",
        "shared_name" : "39 (interacts with) Pol",
        "shared_interaction" : "interacts with",
        "name" : "39 (interacts with) Pol",
        "interaction" : "interacts with",
        "SUID" : 610,
        "Column_4" : 8,
        "BEND_MAP_ID" : 610,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}