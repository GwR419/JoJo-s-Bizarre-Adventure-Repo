var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Minimal",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 42.0,
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "font-size" : 9,
      "background-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "height" : 42.0,
      "shape" : "rectangle",
      "color" : "rgb(51,51,51)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 2.0,
      "line-color" : "rgb(76,76,76)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Nested Network Style",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 60.0,
      "border-width" : 2.0,
      "border-color" : "rgb(0,0,0)",
      "font-size" : 12,
      "background-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "height" : 40.0,
      "shape" : "ellipse",
      "color" : "rgb(0,0,0)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(shared_name)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "border-color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "text-valign" : "bottom"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Curved",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 18.0,
      "border-width" : 7.0,
      "border-color" : "rgb(255,255,255)",
      "font-size" : 14,
      "background-color" : "rgb(254,196,79)",
      "background-opacity" : 1.0,
      "height" : 18.0,
      "shape" : "ellipse",
      "color" : "rgb(102,102,102)",
      "text-valign" : "bottom",
      "text-halign" : "right",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(255,255,255)",
      "opacity" : 1.0,
      "width" : 3.0,
      "line-color" : "rgb(255,255,255)",
      "target-arrow-shape" : "triangle",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(255,255,255)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample2",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 50.0,
      "border-width" : 15.0,
      "border-color" : "rgb(255,255,255)",
      "font-size" : 20,
      "background-color" : "rgb(58,127,182)",
      "background-opacity" : 1.0,
      "height" : 50.0,
      "shape" : "ellipse",
      "color" : "rgb(102,102,102)",
      "text-valign" : "center",
      "text-halign" : "right",
      "text-opacity" : 1.0,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 20.0,
      "line-color" : "rgb(255,255,255)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Solid",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 40.0,
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "font-size" : 14,
      "background-color" : "rgb(102,102,102)",
      "background-opacity" : 1.0,
      "height" : 40.0,
      "shape" : "ellipse",
      "color" : "rgb(0,0,0)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 12.0,
      "line-color" : "rgb(204,204,204)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Marquee",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 20.0,
      "border-width" : 10.0,
      "border-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "background-color" : "rgb(0,204,255)",
      "background-opacity" : 1.0,
      "height" : 20.0,
      "shape" : "ellipse",
      "color" : "rgb(102,102,102)",
      "text-valign" : "bottom",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 8,
      "line-style" : "dashed",
      "source-arrow-color" : "rgb(255,255,255)",
      "opacity" : 1.0,
      "width" : 2.0,
      "line-color" : "rgb(255,255,255)",
      "target-arrow-shape" : "triangle",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(102,102,102)",
      "target-arrow-color" : "rgb(255,255,255)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 25.0,
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "background-color" : "rgb(127,205,187)",
      "background-opacity" : 1.0,
      "height" : 25.0,
      "shape" : "ellipse",
      "color" : "rgb(51,51,51)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 1.0,
      "line-color" : "rgb(153,153,153)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(51,51,51)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[interaction = 'pp']",
    "css" : {
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[interaction = 'pd']",
    "css" : {
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Big Labels",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 5.0,
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "font-size" : 24,
      "background-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "height" : 5.0,
      "shape" : "ellipse",
      "color" : "rgb(51,51,51)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 1.0,
      "line-color" : "rgb(183,183,183)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "size_rank",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 12.0,
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "font-size" : 9,
      "background-color" : "rgb(204,204,255)",
      "background-opacity" : 1.0,
      "height" : 12.0,
      "shape" : "rectangle",
      "color" : "rgb(51,51,51)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 2.0,
      "line-color" : "rgb(76,76,76)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default black",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 15.0,
      "border-width" : 0.0,
      "border-color" : "rgb(0,153,0)",
      "font-size" : 12,
      "background-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "height" : 15.0,
      "shape" : "ellipse",
      "color" : "rgb(204,204,204)",
      "text-valign" : "bottom",
      "text-halign" : "right",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 2.0,
      "line-color" : "rgb(0,153,0)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 75.0,
      "border-width" : 0.0,
      "border-color" : "rgb(204,204,204)",
      "font-size" : 12,
      "background-color" : "rgb(137,208,245)",
      "background-opacity" : 1.0,
      "height" : 35.0,
      "shape" : "roundrectangle",
      "color" : "rgb(0,0,0)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[name = 'Borgh,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Crush,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Crunch,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Baaaaaa,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Boom,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Crack,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Kabaam,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Jump,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Bagyah,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Bzzzzzz,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Crunch,sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Menace,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Bam,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Pop,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Crunch,Trish']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Thud,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Fwip,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Rumble,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Loom,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Crunch,Sign']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Bazoo,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[name = 'Plop,Sfx']",
    "css" : {
      "background-color" : "rgb(65,171,93)"
    }
  }, {
    "selector" : "node[Column_2 = 'epTitle']",
    "css" : {
      "shape" : "v"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 2.0,
      "line-color" : "rgb(132,132,132)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge[Column_4 > 177]",
    "css" : {
      "line-color" : "rgb(102,37,6)"
    }
  }, {
    "selector" : "edge[Column_4 = 177]",
    "css" : {
      "line-color" : "rgb(153,52,4)"
    }
  }, {
    "selector" : "edge[Column_4 > 89][Column_4 < 177]",
    "css" : {
      "line-color" : "mapData(Column_4,89,177,rgb(254,153,41),rgb(153,52,4))"
    }
  }, {
    "selector" : "edge[Column_4 > 1][Column_4 < 89]",
    "css" : {
      "line-color" : "mapData(Column_4,1,89,rgb(255,247,188),rgb(254,153,41))"
    }
  }, {
    "selector" : "edge[Column_4 = 1]",
    "css" : {
      "line-color" : "rgb(255,247,188)"
    }
  }, {
    "selector" : "edge[Column_4 < 1]",
    "css" : {
      "line-color" : "rgb(255,255,229)"
    }
  }, {
    "selector" : "edge[Column_4 > 177]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[Column_4 = 177]",
    "css" : {
      "width" : 12.715291403173431
    }
  }, {
    "selector" : "edge[Column_4 > 1][Column_4 < 177]",
    "css" : {
      "width" : "mapData(Column_4,1,177,1.5321890668171207,12.715291403173431)"
    }
  }, {
    "selector" : "edge[Column_4 = 1]",
    "css" : {
      "width" : 1.5321890668171207
    }
  }, {
    "selector" : "edge[Column_4 < 1]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Universe",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 40.0,
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "font-size" : 18,
      "background-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "height" : 40.0,
      "shape" : "ellipse",
      "color" : "rgb(255,255,255)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "Monospaced.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "dashed",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 2.0,
      "line-color" : "rgb(153,153,153)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample3",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 20.0,
      "border-width" : 8.0,
      "border-color" : "rgb(255,255,255)",
      "font-size" : 14,
      "background-color" : "rgb(61,154,255)",
      "background-opacity" : 1.0,
      "height" : 20.0,
      "shape" : "ellipse",
      "color" : "rgb(206,206,206)",
      "text-valign" : "bottom",
      "text-halign" : "right",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 2.0,
      "line-color" : "rgb(255,255,255)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Directed",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 45.0,
      "border-width" : 5.0,
      "border-color" : "rgb(145,145,145)",
      "font-size" : 8,
      "background-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "height" : 45.0,
      "shape" : "ellipse",
      "color" : "rgb(51,153,255)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 12,
      "line-style" : "solid",
      "source-arrow-color" : "rgb(204,204,204)",
      "opacity" : 1.0,
      "width" : 5.0,
      "line-color" : "rgb(204,204,204)",
      "target-arrow-shape" : "triangle",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(51,153,255)",
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Gradient1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 30.0,
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "font-size" : 8,
      "background-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "height" : 30.0,
      "shape" : "ellipse",
      "color" : "rgb(204,204,204)",
      "text-valign" : "bottom",
      "text-halign" : "right",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 1.0,
      "line-color" : "rgb(102,102,102)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Ripple",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 50.0,
      "border-width" : 20.0,
      "border-color" : "rgb(51,153,255)",
      "font-size" : 8,
      "background-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "height" : 50.0,
      "shape" : "ellipse",
      "color" : "rgb(19,58,96)",
      "text-valign" : "center",
      "text-halign" : "center",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,204)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "content" : "",
      "line-style" : "solid",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "width" : 3.0,
      "line-color" : "rgb(51,153,255)",
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]